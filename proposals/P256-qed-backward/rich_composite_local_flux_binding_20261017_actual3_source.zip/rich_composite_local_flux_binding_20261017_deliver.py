"""Package only completed physical results; no producer replay or approval gate."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import sys
import zipfile
ROOT = Path(__file__).resolve().parent
PREFIX = 'rich_composite_local_flux_binding_20261017_'


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    actual_stamp, control_stamp, post_stamp = sys.argv[1:4]
    load = lambda name: json.loads((ROOT/(PREFIX+name)).read_text())
    actual, control, post = [load(stamp+'_result.json') for stamp in [actual_stamp, control_stamp, post_stamp]]
    exits = {stamp: load(stamp+'_exit.json') for stamp in [actual_stamp, control_stamp, post_stamp]}
    if any(row['returncode'] != 0 for row in exits.values()):
        raise ValueError('Missing natural completed physical consumer')
    typing = load('language_final.json')
    ground, off = actual['ground'], control['ground']
    rotation = post['ground_block_joint_spatial_spin_rotation']
    lines = [
        'NEW LOCAL NON-ABELIAN THREE-QUARK BINDING CANDIDATE: actual finite variational physics, not a proton/QCD claim.',
        'Backward target: extended moving charge1/halfspin odd uud object, with quantum relative motion, local deformation, SU3 flux and sea feedback.',
        'Chosen physical geometry:4 regular-tetrahedral sites in genuine3D, all6 primitive hopping links. No external one-body trap or prescribed whole-trimer hop; finite graph is not a bulk dispersion or exact COM/internal tensor factorization.',
        'Unprojected law: SU3 matrix multiplication U_ab/electric Casimirs/left-right Gauss generators + same72-mode canonical CAR u,d,anti-u + independent local trace-matrix Phi_s=X_s I3. Primitive masses/charges/spins/gauging are explicit hypotheses, not Nature-derived.',
        'Approximation: covariant1+3+bar3 PW19 links with ACTUAL epsilon/delta intertwiners/noncommuting generators; NOT a Z3 clock. The discarded6/8/higher link channels and nonunitarity of PUP remain real physical debt.',
        'Local quantum field: omega bdagb+lambda X4-g Ntotal X and edge gradients. Conditional2 vibronic states/load0..18 from bare32 basis; X2/X4 evaluated before primitive cutoff. Independent four-site clouds, not a global breather or inserted pair potential.',
        'Primitive spin-orbit hopping and the same canonical CAR signs supply current/spin/transport. Local spin-colour singlet u/anti-u creation plus actual gauge-covariant quark/antiquark hopping admits mixed local-colour+flux states. No permanently singlet-only sea ladder.',
        'Heavy anti-u mass/pair vertex are NEW law inputs. Word-order limitations are explicit (ordinary depth2 admits2 extra pairs), not a microscopic one-pair cap; higher particle/field/colour response is not claimed closed.',
        f'Executed parameters={actual["parameters"]}. Pure-electric kB0 is a strong-coupling regime; independent Wilson-loop seed directions and non-Abelian virtual constituent loops remain.',
        f'Actual source CAR norm2={actual["primitive"]["bare_dressed_source_norm2"]:.12g}; H-source all32 Gauss maxnorm2={actual["primitive"]["first_H_max_Gauss2"]:.5g}. Exact global colour singlet and local Gauss follow invariant sources/operators/projectors; no external coloured fragments or B-L atom.',
        f'Actual primitive union={actual["primitive_support"]}, variational rank={actual["rank"]}; all generated occupation channels retain quantum relative positions. Actual Gram error={actual["actual_metric_error"]:.4g}, primitive Hermiticity={actual["primitive_hermiticity"]:.4g}. Numerical null spectra/weights retained separately.',
        'H-word/relative-channel Galerkin selection is an explicit strong-coupling variational approximation, NOT a fixed cluster projection or full-H exterior-norm/ground theorem.',
        f'Finite E_min={actual["eigenvalues"][0]:.10g}; same-H legal separated relative variational E={actual["finite_same_H_separated_energy"]:.10g}; finite cost={actual["finite_relative_cost"]:.8g}.',
        actual['separation_scope'],
        'That constrained variational cost is not by itself a breakup proof: projection/finite-volume kinetic costs also occur in the OFF control. Isolated coloured pair+single energies are NOT invented thresholds.',
        f'Coupled ground: Q={ground["total_charge"]:.12g}, zero-extra-pair compact weight={ground["zero_pair_compact_weight"]:.8g}, separated weight={ground["zero_pair_all_separated_weight"]:.8g}, weighted pair-radius2={ground["zero_pair_weighted_pair_radius2"]:.8g}. These zero-pair weights are not whole-sea/tagged-added-quark probabilities.',
        f'Colour/sea/cloud: electric Casimir={ground["electric_Casimir"]:.8g}; Nanti={sum(ground["antiparticle_density"]):.8g}; P>=2 extra pairs={ground["at_least_two_sea_pairs"]:.8g}; mixed screening-pattern weight={ground["mixed_screening_pattern_weight"]:.8g}; cloud excitation={ground["cloud_excitation_number"]:.8g}.',
        f'Quantum mean Phi={ground["quantum_phi_mean"]}; weighted local bare-top indicator={ground["local_basis_top_population"]:.5g}, not a demonstrated cutoff-convergence bound.',
        f'Ground block dimension={post["ground_degeneracy"]}; actual primitive spin2={post["ground_block_primitive_spin2"]}; source spin2={post["source_spin2"]:.12g}. SOC need not conserve primitive S2.',
        f'Joint physical120degree tetrahedral rotation character={rotation["character"]}; ground-block unitarity error={rotation["ground_block_unitarity_error"]:.4g}, R3+I error={rotation["triple_rotation_minus_identity_error"]:.4g}.',
        'Finite double-group character is real space+spin+link rotation, not merely internal spin SO3 and not exact continuum J. Odd-CAR/primitive spin inputs remain assumptions; no Noether-derived halfspin or uniqueness/pole claim.',
        f'Active mediator-OFF SAME canonical SU3/PW19 hopping model: E={control["eigenvalues"][0]:.10g}, compact={off["zero_pair_compact_weight"]:.8g}, separated={off["zero_pair_all_separated_weight"]:.8g}, pair-radius2={off["zero_pair_weighted_pair_radius2"]:.8g}; finite constrained cost={control["finite_relative_cost"]:.8g}.',
        'OFF removes g, sea-pair vertex and electric cost, retains actual hopping/SOC and owns its own generated basis/clock0 ray. It is a DIFFERENT-parameter causal discriminator, never a same-H breakup threshold or borrowed solved background.',
        f'Canonical Bdag on prepared empty-sea field reference: full CAR/source norm2={post["canonical_source_full_norm2"]:.12g}; local conditional-field projected weight={post["canonical_source_local_field_projection_norm2"]:.8g}; actual Galerkin weight={post["canonical_source_Galerkin_projection_norm2"]:.8g}.',
        'DRESSED clock0 sources and bare canonical sources are distinct. Missing canonical strength is retained as exterior/ansatz debt, not renormalized into a false complete emission probability.',
        'EM here is an EXTERNAL current probe only. Owning J=-d_AH/contact=d_A2H from constituent Peierls phases and actual nonorthogonal metric; no dynamical EM/photon dressing, momentum=current identification, or whole-trimer charge operator substitution.',
        'Fresh matched neutral evolves under the SAME primitive law/absolute clock from its own prepared reference and own operator-orbit basis. Signed excesses are not probabilities or excitation PVMs.',
    ]
    for charged, off_record, current in zip(actual['compact_dressed_source_trajectory'], control['compact_dressed_source_trajectory'], post['charged_current_trajectory']):
        lines.append(f't={charged["absolute_time"]:g}: coupled compact={charged["zero_pair_compact_weight"]:.8g}, OFF compact={off_record["zero_pair_compact_weight"]:.8g}; charge-profile={charged["charge_density"]}; J={current["owning_uniform_current"]}; S2={current["primitive_spin_squared"]:.8g}.')
    lines += [
        'Motion is actual same-H propagation through virtual constituent hops/fields in the declared Galerkin space, not a prescribed centre hopping term. Finite-time retention and relocation are not an asymptotic lifetime or inertial mass measurement.',
        f'Natural exits={exits}; selected typing exit={typing["natural_exit"]}, summary={typing["diagnostics"]["summary"]}; real rooted LSP exit={typing["rooted_LSP"]["natural_exit"]}.',
        'No parameter fit to measured masses, fullQCD/confinement/pole/theorem, field/word-order/link/volume convergence, Nature antiparticle/proton or same-law electron/photon join claim.',
        'Old recoil capsule e3e1c4df/source files remain immutable. Centre-only cube proposal/control preserved UNEXECUTED, not relabelled this rich SU3 supplier. No peer state, solved background or old clamped energy curve is imported.',
    ]
    if len(lines) > 80:
        raise ValueError('Physics synthesis exceeds80 lines')
    (ROOT/(PREFIX+'synthesis.txt')).write_text('\n'.join(lines)+'\n')
    interface = dict(kind='ACTUAL_NONABELIAN_LOCAL_COMPOSITE_CANDIDATE_INTERFACE', root=str(ROOT), model=PREFIX+'model.py',
        law='Law: actual SU3/PW19, canonical CAR, conditional local clouds, H/current/colour Wilson/sea actions',
        consumer=PREFIX+'execute.py', actual=actual_stamp, control=control_stamp, post=post_stamp,
        scope='Finite strong-coupling H/current-generated quantum Galerkin candidate; no exact full-H closure or continuum/proton proof',
        source_sha256={path.name:sha(path) for path in sorted(ROOT.glob(PREFIX+'*.py'))})
    (ROOT/(PREFIX+'interface.json')).write_text(json.dumps(interface, indent=2)+'\n')
    capsule = ROOT/(PREFIX+'delivery_capsule.zip')
    manifest_path = ROOT/(PREFIX+'manifest.json')
    receipt_path = ROOT/(PREFIX+'delivery_receipt.json')
    files = [path for path in sorted(ROOT.glob(PREFIX+'*')) if path.is_file() and path not in [capsule, manifest_path, receipt_path]]
    manifest = dict(kind='IMMUTABLE_PHYSICAL_SOURCE_INPUT_RUNTIME_ARRAY_CAPSULE', files={path.name:dict(bytes=path.stat().st_size, sha256=sha(path)) for path in files})
    manifest_path.write_text(json.dumps(manifest, indent=2)+'\n')
    with zipfile.ZipFile(capsule, 'w', compression=zipfile.ZIP_STORED) as archive:
        for path in files+[manifest_path]:
            archive.write(path, path.name)
    receipt = dict(capsule=capsule.name, sha256=sha(capsule), bytes=capsule.stat().st_size,
        manifest_sha256=sha(manifest_path), synthesis_lines=len(lines))
    receipt_path.write_text(json.dumps(receipt, indent=2)+'\n'); print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    main()
