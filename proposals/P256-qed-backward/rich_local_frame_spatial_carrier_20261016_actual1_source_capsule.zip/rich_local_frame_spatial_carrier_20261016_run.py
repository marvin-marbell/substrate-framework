"""Actual full-H MPS images, matched background and two-way field intervention."""
from __future__ import annotations
import gc
import hashlib
import json
import pickle
from pathlib import Path
import time
import numpy as np
from scipy.linalg import expm
from rich_local_frame_spatial_carrier_20261016_model import Model, PREFIX, physical_element
ROOT=Path(__file__).resolve().parent


def save(name,data):
    (ROOT/(PREFIX+name+'.json')).write_text(json.dumps(data,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x))+'\n')


def store(name,state):
    with (ROOT/(PREFIX+name+'.pkl')).open('wb') as f:pickle.dump(state,f,protocol=5)


def normalize(psi):
    raw=float(psi.overlap(psi).real)
    psi.canonical_form(renormalize=False);psi.norm=1.
    return raw


def apply(H,psi,chi):
    image=psi.copy()
    err=H.apply(image,{'compression_method':'zip_up','trunc_params':{'chi_max':chi,'svd_min':1e-12}})
    image.canonical_form(renormalize=False)
    return image,dict(discarded=float(err.eps),image_norm2=float(image.overlap(image).real),chi=max(image.chi))


def step(model,psi,dt,chi):
    """Second-order polynomial in FULL H, with each image compression disclosed."""
    E=float(physical_element(psi,model.H,psi).real)
    # Subtract a scalar phase to make the polynomial's physical error modest.
    shifted=model.mpo(model.terms+[model.term(-E,{0:np.eye(3)})])
    first,a=apply(shifted,psi,chi)
    second,b=apply(shifted,first,chi)
    result=psi.add(first,1.,-1j*dt)
    result=result.add(second,1.,-.5*dt*dt)
    error=result.compress_svd({'chi_max':chi,'svd_min':1e-12})
    norm=normalize(result)
    return result,dict(dt=dt,energy_phase=E,first=a,second=b,addition_discarded=float(error.eps),pre_normalization_norm2=norm,unitarity_defect=norm-1,method='Normalized RK2 full-H MPS images; finite polynomial and bond errors NOT asserted zero. No variance inferred from norm metadata.')


def outgoing(model,state):
    """Actual populated angular/field edge images; no global convergence claim."""
    rows=[]
    for v in range(4):
        O=model.g['O'][0][0].toarray()
        # Multiplication by O00 has exact squared norm integral; compression
        # cannot replace P O² P by (P O P)².
        f=model.g['F'];w=model.g['weights']
        # The quadrature's own O data came from genuine SU2 rotations. Recover
        # O00 values from fundamental D and evaluate their products directly.
        from rich_gauge_band_frame_20261016_model import jmat
        J=jmat(.5);P=[2*a for a in J]
        values=[]
        for a,b,c in model.g['points']:
            u=expm(-1j*a*J[2])@expm(-1j*b*J[1])@expm(-1j*c*J[2])
            values.append(np.trace(P[0]@u@P[0]@u.conj().T).real/2)
        exact=f.conj().T@(w[:,None]*np.asarray(values)[:,None]**2*f)
        leakage=(exact-O.conj().T@O);leakage=(leakage+leakage.conj().T)/2
        rows.append(float(physical_element(state,model.observable(model.gsites[v],leakage),state).real))
    # All eight Q image deficits see the unrepresented total-occupation shell.
    field=[]
    for a in range(8):
        leak=model.QQ[a,a]-model.Q[a]@model.Q[a]
        field.append(float(physical_element(state,model.observable(model.rfsite,np.kron(np.eye(model.nR),leak)),state).real))
    return dict(actual_local_O00_outgoing_norm2=rows,actual_field_Q_outgoing_norm2=field,scope='Actual-state individual raw multiplication images outside Galerkin regulator, NOT norm of total exterior H image, not a convergence bound. Full H images inside regulator are evolved; no occupied angular shell declared safe.')


def main():
    start=time.time();m=Model();save('build',dict(parameters=m.parameters,signature=m.signature,positions=m.positions.tolist(),modes=m.modes.tolist(),Fock_modes=32,Fock_sector_dimensions={'N15':565722720,'N16':601080390,'N17':565722720},CAR_representation='All32 binary local CAR modes, explicit Jordan-Wigner, no virtual-configuration projection',local_g_labels=m.g['labels'],material_labels=m.material['labels'],field_basis=m.basis.tolist(),MPO_bonds=m.H.chi,terms=len(m.terms),time=time.time()-start))
    print('MODEL_READY',m.signature,len(m.terms),max(m.H.chi),flush=True)
    with (ROOT/(PREFIX+'model.pkl')).open('wb') as f:pickle.dump(m,f,protocol=5)
    neutral=m.seed();addition,addnorm=m.source(neutral,0,0,True,chi=12);removal,remnorm=m.source(neutral,0,1,False,chi=12)
    kicked=addition.copy();kick=expm(.28j*np.kron(np.eye(m.nR),m.Q[0]));kicked.apply_local_op(m.rfsite,m.register(m.rfsite,kick),unitary=True,renormalize=False);normalize(kicked)
    states={'neutral':neutral,'addition':addition,'removal':removal,'addition_field_kick':kicked}
    result=dict(kind='ACTUAL_FOUR_LOCAL_SEWN_CAR32_AND_EIGHT_FINITE_Q_FIELD_SAME_H',law=m.signature,architecture='Physical charged32 microsites x_s(R)=R xbody_s; not lab-fixed texture alternative',source_raw_norm2={'addition':addnorm,'removal':remnorm},times=[0.,.04,.08],trajectories={},limits=['Finite g j<=2, material l<=2, eight-field total occupation<=1, r3 Friedrichs grid, finite chi and normalized RK2; no stationary ground, pole, photon, inertial mass or global angular convergence claim.','Whole-CAR32 representation permits all N15/N16/N17 virtual configurations; finite chi compresses entanglement and errors are measured, not projected-source evolution.','Scalar edge current is distinct from physical lab-mode derivative, which includes all microscopic paths and rotating ions.'])
    for name,psi in states.items():
        measurements=[m.measure(psi)];store(name+'_t0',psi);ledgers=[]
        for k in range(2):
            psi,ledger=step(m,psi,.04,12);ledgers.append(ledger);measurements.append(m.measure(psi));store(name+'_t'+str(k+1),psi)
            print('EVOLVED',name,k+1,json.dumps(measurements[-1]),flush=True)
        result['trajectories'][name]=dict(measurements=measurements,steps=ledgers,outgoing=outgoing(m,psi));save('result_partial',result)
        states[name]=psi
    for name in ('addition','removal'):
        result['trajectories'][name]['excess_matched_background']=[{key:(np.asarray(a[key])-np.asarray(b[key])).tolist() for key in ('n_cells','local_LEFT','local_r2','field_Q')} for a,b in zip(result['trajectories'][name]['measurements'],result['trajectories']['neutral']['measurements'])]
    result['field_to_carrier']=[{key:(np.asarray(a[key])-np.asarray(b[key])).tolist() for key in ('n_cells','local_LEFT','local_r2','field_Q')} for a,b in zip(result['trajectories']['addition_field_kick']['measurements'],result['trajectories']['addition']['measurements'])]
    result['carrier_to_field']=result['trajectories']['addition']['excess_matched_background']
    # Independent bond increase on the same preparation and fullH image, not
    # differences between independently optimized states.
    fine,_=m.source(neutral,0,0,True,chi=20);coarse,_=step(m,fine,.04,12);fine,ledger=step(m,fine,.04,20)
    result['same_input_chi12_20']=dict(distance_squared=float(coarse.overlap(coarse).real+fine.overlap(fine).real-2*coarse.overlap(fine).real),fine_ledger=ledger)
    store('chi20_addition_t1',fine)
    # Physical nonforward lab current/contact, not the scalar-edge derivative.
    result['physical_lab_sources']={}
    for a in (0,4):
        source=m.lab_source(a);contact=m.lab_source(a,a)
        result['physical_lab_sources'][str(a)]={name:dict(current=float(physical_element(psi,source,psi).real),contact=float(physical_element(psi,contact,psi).real)) for name,psi in states.items()}
        del source,contact;gc.collect()
    result['elapsed_seconds']=time.time()-start;save('result',result);print('SCIENCE_COMPLETE',flush=True)


if __name__=='__main__':main()
