"""Owning physical readouts and NEW matched-neutral same-H trajectory.
Not an operator catalogue or replay of the charged producer.
"""
from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import sys
import time
from collections import defaultdict
from typing import Any
import numpy as np
from scipy import sparse
ROOT = Path(__file__).resolve().parent
PREFIX = 'rich_composite_local_flux_binding_20261017_'
spec = importlib.util.spec_from_file_location('local_binding_consumer', ROOT/(PREFIX+'execute.py'))
assert spec is not None and spec.loader is not None
consumer = importlib.util.module_from_spec(spec); sys.modules[spec.name] = consumer; spec.loader.exec_module(consumer)
model = consumer.model


def spin_squared(wave: Any) -> float:
    images: list[dict[int, complex]] = [defaultdict(complex), defaultdict(complex)]
    sz2 = 0.
    for key, amplitude in wave.items():
        bits = key & model.FERMION_MASK
        sz = 0.
        for site in range(4):
            for species in range(3):
                local = bits >> (18*site+6*species)
                sz += ((local & 7).bit_count()-((local >> 3) & 7).bit_count())/2
                for colour in range(3):
                    up, down = 18*site+6*species+colour, 18*site+6*species+3+colour
                    for direction, (target, source) in enumerate([(up, down), (down, up)]):
                        moved = model.fermion(bits, [(True, target), (False, source)])
                        if moved is not None:
                            newbits, sign = moved
                            images[direction][(key & ~model.FERMION_MASK) | newbits] += amplitude*sign
        sz2 += abs(amplitude)**2*sz**2
    return float(sz2+.5*sum(model.inner(image, image).real for image in images))


def owning_uniform_probe(law: Any, keys: list[int], basis: Any, h: Any, metric: Any) -> tuple[list[Any], list[Any], list[Any]]:
    primitive_dipoles = []
    for key in keys:
        channel = law.quantum_channel(key)
        charges = 2/3*np.array(channel[:4])-np.array(channel[4:8])/3
        primitive_dipoles.append(charges@law.positions)
    dipoles = np.array(primitive_dipoles)
    density_ops, currents, contacts = [], [], []
    mh = np.linalg.solve(metric, h)
    for axis in range(3):
        d = (basis.conj().T@basis.multiply(dipoles[:, axis, None])).toarray()
        md = np.linalg.solve(metric, d)
        # Exact owning Peierls derivative in a charge-channel-closed nonorthogonal space.
        commutator = d@mh-h@md
        j = -1j*commutator
        k = -(d@np.linalg.solve(metric, commutator)-commutator@md)
        density_ops.append(d); currents.append(j); contacts.append(k)
    return density_ops, currents, contacts


def tetrahedral_rotation(law: Any, keys: list[int], states: Any) -> dict[str, Any]:
    """Actual joint 120degree spatial/spin/link rotation, not internal SO3."""
    permutation = [0, 2, 3, 1]
    spin = .5*np.eye(2)-.5j*sum(law.sigma, np.zeros((2, 2), dtype=complex))
    lookup = {key: row for row, key in enumerate(keys)}
    matrix = np.zeros((states.shape[1], states.shape[1]), dtype=complex)
    fermion_cache: dict[int, Any] = {}
    for source_row, key in enumerate(keys):
        bits = key & model.FERMION_MASK
        if bits not in fermion_cache:
            occupied = [mode for mode in range(72) if (bits >> mode) & 1]
            partial: dict[int, complex] = {0: 1.+0j}
            for mode in reversed(occupied):
                site, offset = divmod(mode, 18)
                species, spin_colour = divmod(offset, 6)
                old_spin, colour = divmod(spin_colour, 3)
                next_partial: dict[int, complex] = defaultdict(complex)
                for target_spin in range(2):
                    target = 18*permutation[site]+6*species+3*target_spin+colour
                    for oldbits, coefficient in partial.items():
                        created = model.fermion(oldbits, [(True, target)])
                        if created is not None:
                            newbits, sign = created
                            next_partial[newbits] += coefficient*sign*spin[target_spin, old_spin]
                partial = dict(next_partial)
            fermion_cache[bits] = partial
        field = 0
        for edge, (i, j) in enumerate(law.edges):
            state = (key >> (model.FERMIONS+5*edge)) & 31
            first, second = permutation[i], permutation[j]
            target_edge = law.edges.index(tuple(sorted((first, second))))
            if first > second and state != 0:
                offset = 1 if state < 10 else 10
                a, b = divmod(state-offset, 3)
                state = (10 if offset == 1 else 1)+3*b+a
            field |= state << (model.FERMIONS+5*target_edge)
        for site in range(4):
            field |= ((key >> (model.CLOUD_SHIFT+site)) & 1) << (model.CLOUD_SHIFT+permutation[site])
        for target_bits, coefficient in fermion_cache[bits].items():
            row = lookup.get(field | target_bits)
            if row is not None:
                matrix += coefficient*np.outer(states[row].conj(), states[source_row])
    return dict(matrix=[[[float(z.real), float(z.imag)] for z in row] for row in matrix],
        character=[float(np.trace(matrix).real), float(np.trace(matrix).imag)],
        ground_block_unitarity_error=float(np.linalg.norm(matrix.conj().T@matrix-np.eye(len(matrix)))),
        triple_rotation_minus_identity_error=float(np.linalg.norm(np.linalg.matrix_power(matrix, 3)+np.eye(len(matrix)))),
        meaning='Joint tetrahedral double-group character, not a claim of exact continuum J. Fundamental spinor doublet has character1; primitive2pi sign remains an input odd-CAR property.')


def main() -> None:
    stamp = sys.argv[1]; output = sys.argv[2]
    inp = json.loads((ROOT/(PREFIX+stamp+'_input.json')).read_text())
    law = model.Law(inp['parameters']); stem = ROOT/(PREFIX+stamp+'_')
    start = time.time()
    keys = [int(key) for key in json.loads(Path(str(stem)+'primitive_keys.json').read_text())]
    basis = sparse.load_npz(str(stem)+'basis.npz')
    arrays = np.load(str(stem)+'spectrum.npz')
    h, metric, e, v = [arrays[name] for name in ['H', 'metric', 'eigenvalues', 'eigenvectors']]
    source, raw_source = law.baryon(0)
    source_vector = np.array([source.get(key, 0j) for key in keys])
    coeff = v.conj().T@(basis.conj().T@source_vector)
    dipoles, currents, contacts = owning_uniform_probe(law, keys, basis, h, metric)
    ground_indices = np.flatnonzero(np.abs(e-e[0]) < 1e-8)
    ground_spin = []
    for index in ground_indices:
        primitive = basis@v[:, index]
        wave = {key: value for key, value in zip(keys, primitive) if value != 0}
        ground_spin.append(spin_squared(wave))
    rotation = tetrahedral_rotation(law, keys, basis@v[:, ground_indices])
    trajectory = []
    for time_value in inp['times']:
        coordinate = v@(coeff*np.exp(-1j*e*time_value))
        state = basis@coordinate
        wave = {key: value for key, value in zip(keys, state) if value != 0}
        trajectory.append(dict(absolute_time=time_value, primitive_spin_squared=spin_squared(wave),
            electric_dipole=[float(np.vdot(coordinate, d@coordinate).real) for d in dipoles],
            owning_uniform_current=[float(np.vdot(coordinate, j@coordinate).real) for j in currents],
            owning_uniform_contact=[float(np.vdot(coordinate, k@coordinate).real) for k in contacts]))
    # Actual bare canonical source on the prepared empty-sea field reference.
    # Dressed source and bare canonical source are distinct preparations.
    bare_source: dict[int, complex] = {}
    for key, amplitude in source.items():
        for local_state in range(2):
            target = key | (local_state << model.CLOUD_SHIFT)
            bare_source[target] = amplitude*law.overlap[3, 0][local_state, 0]
    bare_vector = np.array([bare_source.get(key, 0j) for key in keys])
    bare_coordinates = basis.conj().T@bare_vector
    raw_bare_norm = float(raw_source*np.linalg.norm(law.local_vectors[0][:, 0])**8)
    raw_bare_local_projection = float(model.inner(bare_source, bare_source).real)
    raw_bare_galerkin_projection = float(np.vdot(bare_coordinates, np.linalg.solve(metric, bare_coordinates)).real)
    neutral_stem = ROOT/(PREFIX+output+'_neutral_')
    neutral = consumer.build(law, inp, neutral_stem, neutral=True)
    vacuum = np.array([1. if key == 0 else 0. for key in neutral['keys']])
    ne, nv = neutral['eigenvalues'], neutral['eigenvectors']
    nc = nv.conj().T@(neutral['basis'].conj().T@vacuum)
    neutral_trajectory = []
    for t in inp['times']:
        coordinates = nv@(nc*np.exp(-1j*ne*t))
        state = neutral['basis']@coordinates
        observation = consumer.observe(law, neutral['keys'], state)
        observation['absolute_time'] = t; neutral_trajectory.append(observation)
    owning = json.loads(Path(str(stem)+'result.json').read_text())
    contrasts = []
    for charged, neutral_observation in zip(owning['compact_dressed_source_trajectory'], neutral_trajectory):
        contrasts.append(dict(absolute_time=charged['absolute_time'],
            signed_inclusive_particle_excess=(np.array(charged['inclusive_particle_density'])-np.array(neutral_observation['inclusive_particle_density'])).tolist(),
            antiparticle_excess=(np.array(charged['antiparticle_density'])-np.array(neutral_observation['antiparticle_density'])).tolist(),
            quantum_phi_excess=(np.array(charged['quantum_phi_mean'])-np.array(neutral_observation['quantum_phi_mean'])).tolist()))
    result = dict(kind='ACTUAL_OWNING_SPIN_EM_CURRENT_AND_PROPAGATED_MATCHED_NEUTRAL', physical_epoch=stamp,
        ground_degeneracy=len(ground_indices), ground_block_primitive_spin2=ground_spin,
        ground_block_joint_spatial_spin_rotation=rotation,
        source_spin2=spin_squared(source), charged_current_trajectory=trajectory,
        neutral_trajectory=neutral_trajectory, charged_minus_propagated_neutral=contrasts,
        canonical_source_full_norm2=raw_bare_norm, canonical_source_local_field_projection_norm2=raw_bare_local_projection,
        canonical_source_Galerkin_projection_norm2=raw_bare_galerkin_projection,
        source_scope='Bare canonical source on prepared empty-sea field reference versus separately declared initially field-DRESSED source. Missing canonical norm is outside ansatz, not absent physical strength.',
        current_scope='Uniform external EM probe, not dynamical EM. J=-d_AH and contact=d_A^2H from literal Peierls/actual metric; no momentum=current identification.',
        neutral_scope='NEW matched neutral under same primitive H, own operator-orbit ansatz, actual clock0 vacuum and own propagation. Not a static old ground subtraction.',
        elapsed_seconds=time.time()-start)
    (ROOT/(PREFIX+output+'_result.json')).write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(dict(stage='post_physics_complete', source_spin2=result['source_spin2'], ground_spin2=ground_spin,
        canonical_full=raw_bare_norm, canonical_projected=raw_bare_galerkin_projection, seconds=time.time()-start)), flush=True)


if __name__ == '__main__':
    main()
