"""Bounded physics handoff; raw MPS/current images remain separate artifacts."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import sys
import zipfile
import numpy as np

ROOT = Path(__file__).resolve().parent
PREFIX = 'rich_recoil_current_wave_20261016_'


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(8*1024*1024):
            digest.update(block)
    return digest.hexdigest()


def distance(a: list[float], b: list[float]) -> float:
    return float(np.linalg.norm(np.array(a)-b))


def main() -> None:
    stamp = sys.argv[1]
    stem = PREFIX+stamp+'_'
    result = json.loads((ROOT/(stem+'result.json')).read_text())
    exit_data = json.loads((ROOT/(stem+'exit.json')).read_text())
    emission = json.loads((ROOT/(stem+'emission_result.json')).read_text())
    typing = json.loads((ROOT/(PREFIX+'language_final.json')).read_text())
    cases = result['cases']
    required = {f'N{number}_{protocol}' for number in [54, 55, 53] for protocol in ['baseline', 'xcos', 'ycos']}
    if set(cases) != required or exit_data['returncode'] != 0 or len(emission['results']) != 4:
        raise ValueError('Incomplete physical construction is not a delivery')
    lines = [
        'NEW FULL108-CAR CURRENT-DRESSED RECOIL WAVE: finite joined physical construction, not an independent review.',
        'Same chosen3^3 law/couplings/CAR/Clifford/spin/scalar data; no Maxwell magnetic, Pauli, new free-Dirac or auxiliary COM sector.',
        'Full108 fermionic occupation sites plus scalar/EM75-state site; no hard local Fock/particle-hole cap or old27/162 Gaussian-source-span closure.',
        'N and actual physical C3z are explicit tensor charges. Three total-C3 components remain a coherent spatial packet, including which(kx,ky)block carries the canonical addition/removal.',
        'Fresh reference Slater is a PREPARED neutral, not a coupled ground. Matched N54 propagates under the new coupled law at the same absolute clock for every protocol.',
        'New H and all four signed before-cut Q_counter J images seed actual sea/internal/field Schmidt directions; two-site TDVP feeds them back through the unchanged H.',
        'Both transverse finite projected-Q-only preparations are labelled finite protocols: NOT full-W, pure photons or asymptotic states.',
        'J=-d_A H and contact=d_A d_A H share the owning Peierls law. Current is neither momentum nor a unitary momentum shift.',
        'QJ and JQ are distinct before-cut products; shell3 is the exact sufficient intermediate for Q times the full Peierls current compressed to shell2.',
        f'Natural physical exit={exit_data["returncode"]}, signal={exit_data["termination_signal"]}; elapsed={result["elapsed_seconds"]:.6g}s; peakKiB={result["peak_resident_KiB"]}.',
    ]
    for number in [54, 55, 53]:
        for protocol in ['baseline', 'xcos', 'ycos']:
            case = cases[f'N{number}_{protocol}']
            first, final = case['observations'][0], case['observations'][-1]
            control0, control1 = case['frozen_interaction_control'][0], case['frozen_interaction_control'][-1]
            lines.append(f'N{number}/{protocol}: rawsource={case["raw_source_norm2"]:.12g}; dm={distance(final["momentum"]["matter"],first["momentum"]["matter"]):.7g}, df={distance(final["momentum"]["field"],first["momentum"]["field"]):.7g}, dtotal={distance(final["momentum"]["total"],first["momentum"]["total"]):.3g}; frozen dm/df={distance(control1["momentum"]["matter"],control0["momentum"]["matter"]):.3g}/{distance(control1["momentum"]["field"],control0["momentum"]["field"]):.3g}.')
            lines.append(f'  spin0={first["primitive_frame_spin"]}; spinT={final["primitive_frame_spin"]}; sea P0/P1/P>=2={final["reference_depletion_P0_P1_Pge2"]}; dE={final["physical_energy"]-first["physical_energy"]:.7g}; maxbond={final["maximum_bond"]}.')
    for number in [55, 53]:
        baseline = cases[f'N{number}_baseline']['observations']
        neutral_base = cases['N54_baseline']['observations']
        for protocol in ['xcos', 'ycos']:
            drive = cases[f'N{number}_{protocol}']['observations']
            neutral = cases[f'N54_{protocol}']['observations']
            excess_delta = (np.array(drive[-1]['density'])-neutral[-1]['density'])-(np.array(baseline[-1]['density'])-neutral_base[-1]['density'])
            lines.append(f'N{number}/{protocol} paired: t0 body-density change={distance(drive[0]["density"],baseline[0]["density"]):.3g}; final body change={distance(drive[-1]["density"],baseline[-1]["density"]):.7g}; propagated-neutral-subtracted excess-response L2={np.linalg.norm(excess_delta):.7g}.')
            lines.append(f'  currentsT={drive[-1]["currents"]}; same-law contact, spin-resolved current form factors and both equal-time QJ/JQ orders are retained in raw results.')
    for key, record in emission['results'].items():
        for vertex in record['vertices']:
            j, e = vertex['current'], vertex['counterfield_current_emission']
            lines.append(f'{key}/T{vertex["polarization"]}/sign{vertex["profile_sign"]}: actual J C3delta={vertex["actual_current_C3_charge"]}; rawJ2={j["raw_norm2"]:.8g}; rawQJ2={e["raw_norm2"]:.8g}; conditional spinZ={e["conditional_primitive_spin_z"]:.8g}; conditional sea={e["conditional_reference_depletion"]}.')
    maximum_truncation = max(float(step[r]['truncation_eps']) for case in cases.values() for step in case['evolution'] for r in step)
    lines += [
        'Emission image norms/form factors are not transition probabilities. J shifts total C3 by its measured finite-group character; counterfield QJ mixes no total-C3 sectors, but nonunitary conditioning can reweight their norms.',
        'Full complex cross-vertex Grams, raw MPS current/emission images, conditional joint recoil PVMs and primitive spin are separate retained arrays/states, not reconstructed from scalar bounds.',
        'Frozen matched control removes matter-scalar/EM feedback at phi_center,A=0 but retains physical scalar/EM kinetic and the same chosen initial rays. Original-law current is not renamed frozen-H current.',
        'n_site/N is inclusive particle POVM; signed propagated-neutral-subtracted excess is not a probability or an excitation-position PVM.',
        f'Maximum accumulated TDVP SVD epsilon={maximum_truncation:.8g}; numerical current-space thresholds, initial-ray overlaps, bond ranks and physical energy changes are retained, not replaced by norm conservation.',
        'No field/bond/time/continuum convergence or full-H/global-ground/domain claim. One q/finiteC3, primitive fixed spin, supplied CAR/charge/Clifford/scalar and absent nonuniform longitudinal sector remain explicit.',
        'No free/continuous COM, Noether-derived halfspin, photon pole/on-shell radiation, Lorentz/inertial mass, proton or Nature claim.',
        f'Final selected typing: exit={typing["natural_exit"]}, summary={typing["diagnostics"]["summary"]}; real rooted LSP exit={typing["rooted_LSP"]["natural_exit"]}.',
        'No old/nativeCommon/47/OLD48 evolved state, solved operator or physical result is spliced into this construction. Selected immutable old translation-law constructors are construction input, not independent validation.',
    ]
    if len(lines) > 80:
        raise ValueError(f'Physics synthesis exceeds80 lines: {len(lines)}')
    synthesis = ROOT/(PREFIX+'synthesis.txt')
    synthesis.write_text('\n'.join(lines)+'\n')
    interface = dict(kind='FULL_CAR_CURRENT_DRESSED_RECOIL_CONSTRUCTION_INTERFACE', root=str(ROOT),
        entrypoint=PREFIX+'capture.py <newstamp>', law='rich_spatial_translation_20261015_actual3_input.json',
        APIs=dict(Law='Full108-CAR+scalar/EM MPS and owning same-law Hamiltonian/current/contact/counterfield-emission operators.',
            prepared='Canonical N54/N55/N53 preparation with coherent total-C3 completion of the finite field-only protocol.',
            prepare_current_space='Full H and signed QJ physical images seed new sea/internal/field directions, without old-source projection.',
            CoherentWave='Exact dense tensor contractions of the coherent C3 sum, including inter-(kx,ky) inclusive density/spin.',
            emission='Actual full-CAR current and before-cut QJ images on fresh evolved states, signed finite-C3 transfer and conditional recoil/spin.'),
        scope='Finite regulator and adaptive numerical projection, not old finiteH equality or Nature proof.',
        source_sha256={p.name: sha(p) for p in sorted(ROOT.glob(PREFIX+'*.py'))})
    (ROOT/(PREFIX+'interface.json')).write_text(json.dumps(interface, indent=2)+'\n')
    capsule = ROOT/(PREFIX+'delivery_capsule.zip')
    manifest_path = ROOT/(PREFIX+'manifest.json')
    receipt_path = ROOT/(PREFIX+'delivery_receipt.json')
    paths = [p for p in sorted(ROOT.glob(PREFIX+'*')) if p.is_file() and p not in [capsule, manifest_path, receipt_path]]
    manifest = dict(files={p.name: dict(bytes=p.stat().st_size, sha256=sha(p)) for p in paths}, synthesis_lines=len(lines),
        physical_exit=exit_data, source_and_scope='All executed epochs retain their own immutable input/source/exit captures. Current source hashes do not relabel earlier computations.')
    manifest_path.write_text(json.dumps(manifest, indent=2)+'\n')
    with zipfile.ZipFile(capsule, 'w', compression=zipfile.ZIP_STORED) as archive:
        for p in paths+[manifest_path]:
            archive.write(p, p.name)
    receipt = dict(capsule=capsule.name, sha256=sha(capsule), bytes=capsule.stat().st_size,
                   manifest_sha256=sha(manifest_path), synthesis_lines=len(lines))
    receipt_path.write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    main()
