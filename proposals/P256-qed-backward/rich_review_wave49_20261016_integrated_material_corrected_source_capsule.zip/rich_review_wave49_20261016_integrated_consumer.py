"""Independent fresh full-CAR32 MPS consumer of the chosen integrated47 law."""
from pathlib import Path
from types import SimpleNamespace
import json
import numpy as np
from scipy.linalg import expm
from tenpy.algorithms.mpo_evolution import ExpMPOEvolution
import rich_local_frame_spatial_carrier_20261016_model as law
import rich_spatial_frame_photon_20261016_fields as fields

ROOT=Path(__file__).resolve().parent;P='rich_review_wave49_20261016_'


def advance(m,psi,H=None,dt=.005,steps=4,chi=16,normalize=True):
    out=psi.copy();engine=ExpMPOEvolution(out,SimpleNamespace(H_MPO=m.H if H is None else H),dict(order=2,approximation='II',compression_method='zip_up',trunc_params=dict(chi_max=chi,svd_min=1e-11)))
    engine.prepare_evolve(dt);error=engine.evolve(steps,dt)
    raw_norm=float(out.overlap(out).real);out.canonical_form(renormalize=False)
    if normalize:out.norm=1.
    return out,dict(dt=dt,steps=steps,chi_cap=chi,truncation_eps=float(error.eps),raw_norm2=raw_norm)


def recipe(m,name):
    key=next((k for k,v in m.ops[m.rfsite].items() if v==name),None)
    return m.rfrecipes.get(key)


def choose_terms(m,whole=False):
    out=[]
    for term in m.terms:
        rf=next((name for name,i in term[1] if i==m.rfsite),None)
        r=recipe(m,rf)
        if r is not None and (whole or r[0]=='phase'):continue
        out.append(term)
    return out


def source_for_terms(m,terms,mode=0):
    original=m.terms
    try:m.terms=terms;return m.lab_source(mode)
    finally:m.terms=original


def measure(m,psi,J):
    out=m.measure(psi);out['local_LEFT_Casimir']=[float(law.physical_element(psi,m.observable(site,m.g['casimir'].toarray()),psi).real) for site in m.gsites]
    out['physical_lab_current']=[float(law.physical_element(psi,j,psi).real) for j in J]
    out['field_shell_weight']=float(law.physical_element(psi,m.observable(m.rfsite,np.kron(np.eye(m.nR),np.diag([sum(v)==m.parameters['field_cap'] for v in m.basis]))),psi).real)
    basis=[tuple(v) for v in m.basis]
    out['physical_field_Pi']=[float(law.physical_element(psi,m.observable(m.rfsite,np.kron(np.eye(m.nR),fields.primitive(basis,basis,a,'p').toarray())),psi).real) for a in (0,4)]
    out['total_n_fraction']=(np.asarray(out['n_cells'])/sum(out['n_cells'])).tolist()
    return out


def save_state(arrays,label,psi):
    arrays[label+'_norm']=np.array(psi.norm)
    arrays[label+'_charge']=np.asarray(psi.get_total_charge(only_physical_legs=True))
    for i in range(psi.L):
        arrays[f'{label}_B_{i:02}']=psi.get_B(i,form='B').to_ndarray()
        arrays[f'{label}_S_{i:02}']=np.asarray(psi.get_SL(i))


def run():
    m=law.Model();neutral,ne=advance(m,m.seed(),dt=.002,steps=2)
    J=[m.lab_source(a) for a in (0,4)];contact=m.lab_source(0,4)
    nohopterms=choose_terms(m);wholeterms=choose_terms(m,whole=True)
    nohopH=m.mpo(nohopterms);wholeH=m.mpo(wholeterms)
    convection=source_for_terms(m,nohopterms);wholeJ=source_for_terms(m,wholeterms)
    records={};arrays={};save_state(arrays,'neutral',neutral)
    for create in (True,False):
        strengths=[]
        for component in range(8):
            _,strength=m.source(neutral,0,component,create,chi=16)
            strengths.append(strength)
        generator=-m.geo['spin'][2].T if create else m.geo['spin'][2]
        eigenvalues,eigenvectors=np.linalg.eigh(generator)
        possible=[i for i,x in enumerate(eigenvalues) if x>.49]
        mu=max(possible,key=lambda i:np.dot(abs(eigenvectors[:,i])**2,strengths))
        polarization=eigenvectors[:,mu]
        selected,best=m.source(neutral,0,polarization,create,chi=16)
        assert best>1e-10,strengths
        state=selected;beforekick=measure(m,state,J)
        assert abs(beforekick['local_LEFT'][0][2])>.1,beforekick['local_LEFT']
        qkick=np.kron(np.eye(m.nR),expm(.19j*m.Q[0]+.13j*m.Q[4]))
        state.apply_local_op(m.rfsite,m.register(m.rfsite,qkick),unitary=True,renormalize=False)
        state.canonical_form(renormalize=False);state.norm=1.
        initial=measure(m,state,J)
        final,errors=advance(m,state);nohop,nohoperror=advance(m,state,nohopH);whole,wholeerror=advance(m,state,wholeH)
        finalobs=measure(m,final,J);wholeobs=measure(m,whole,J)
        # Same-law evolving neutral observer: no n/N excitation proxy.
        neutral_final,neutralerror=advance(m,neutral)
        neutralobs=measure(m,neutral_final,J)
        charge=-(np.asarray(finalobs['n_cells'])-neutralobs['n_cells'])
        spin=np.asarray(finalobs['local_LEFT_Casimir'])-neutralobs['local_LEFT_Casimir']
        charge0=-(np.asarray(initial['n_cells'])-m.measure(neutral,energy=False)['n_cells'])
        spin0=np.asarray(initial['local_LEFT_Casimir'])-measure(m,neutral,J)['local_LEFT_Casimir']
        chargechange=charge-charge0;spinchange=spin-spin0
        vectorchange=(np.asarray(finalobs['local_LEFT'])-neutralobs['local_LEFT'])-(np.asarray(initial['local_LEFT'])-m.measure(neutral,energy=False)['local_LEFT'])
        current=float(law.physical_element(state,J[0],state).real)
        conv=float(law.physical_element(state,convection,state).real)
        wholecurrent=float(law.physical_element(state,wholeJ,state).real)
        feedback=float(abs(final.overlap(whole)))
        assert np.linalg.norm(chargechange[1:])>1e-10,chargechange
        assert np.linalg.norm(spinchange[1:])>1e-10,spinchange
        assert np.linalg.norm(vectorchange[1:])>1e-10,vectorchange
        assert abs(wholecurrent)<1e-11,wholecurrent
        response=[]
        for j in J:
            image=state.copy()
            j.apply(image,{'compression_method':'zip_up','trunc_params':{'chi_max':16,'svd_min':1e-11}})
            image.canonical_form(renormalize=False)
            evolved,err=advance(m,image,dt=.002,steps=1,normalize=False)
            response.append((evolved,err))
        observed,observed_error=advance(m,state,dt=.002,steps=1)
        c01=law.physical_element(observed,J[1],response[0][0])
        c10=law.physical_element(observed,J[0],response[1][0])
        branch='addition' if create else 'removal'
        records[branch]=dict(source_strengths_all8=strengths,selected_component=mu,source_strength=best,initial=initial,final=finalobs,whole_OFF=wholeobs,hopping_OFF=measure(m,nohop,J),evolved_neutral=neutralobs,physical_excess_charge=charge.tolist(),physical_excess_local_LEFT=spin.tolist(),excess_charge_change=chargechange.tolist(),excess_LEFT_change=spinchange.tolist(),wrong_global_spin_density_error=float(np.linalg.norm(spinchange)),physical_source_current=current,hopping_OFF_convection_current=conv,whole_charge_motion_OFF_current=wholecurrent,final_whole_OFF_overlap=feedback,kick_work=initial['energy']-beforekick['energy'],same_H_energy_drift=finalobs['energy']-initial['energy'],mixed_contact=float(law.physical_element(state,contact,state).real),evolution=dict(full=errors,nohop=nohoperror,whole=wholeerror,neutral=neutralerror))
        records[branch]['source_polarization']=[[float(c.real),float(c.imag)] for c in polarization]
        records[branch]['physical_Noether_vector_density_change']=vectorchange.tolist()
        records[branch]['physical_current_time_orders']=[[float(c01.real),float(c01.imag)],[float(c10.real),float(c10.imag)]]
        records[branch]['response_evolution']=[response[0][1],response[1][1],observed_error]
        for label,psi in dict(initial=state,final=final,nohop=nohop,whole=whole,neutral_final=neutral_final).items():save_state(arrays,branch+'_'+label,psi)
        print(branch,json.dumps(records[branch]),flush=True)
    arrays.update(positions=m.positions,modes=m.modes,g_labels=np.array(m.g['labels']),material_labels=np.array(m.material['labels']),radial_nodes=m.rnodes,field_basis=m.basis,ions=m.ions)
    np.savez_compressed(ROOT/(P+'integrated_consumer_raw.npz'),**arrays)
    result=dict(kind='OWN_FRESH_FULLCAR32_INTEGRATED47_CONSUMER',model_signature=m.signature,parameters=m.parameters,neutral_evolution=ne,records=records,limits='One actual chosen47 same-H carrier+finiteq field law. Independent source states, evolving neutral density observer, no producer CLI/state replay. Full32 scalar CAR modes/all virtual sectors represented in MPS; finite chi is truncation, not omitted sector proof. Quantum local g/r/R+8real fields; no localization theorem, photon-gap, globalSO3 cavity closure, Lorentz/inertial mass or convergence claim.')
    (ROOT/(P+'integrated_consumer_result.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)

if __name__=='__main__':run()
