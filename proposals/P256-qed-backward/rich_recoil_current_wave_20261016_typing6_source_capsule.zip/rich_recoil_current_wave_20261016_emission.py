"""Stream the existing saved-state signed-current export; no new evolution."""
from __future__ import annotations
import gc
import hashlib
import json
from pathlib import Path
import pickle
import sys
from typing import Any
import numpy as np
from tenpy.linalg import np_conserved as npc
from tenpy.networks.mpo import MPO

ROOT = Path(__file__).resolve().parent
PREFIX = 'rich_recoil_current_wave_20261016_'


def load(path: Path) -> Any:
    with path.open('rb') as stream:
        return pickle.load(stream)


def dump(path: Path, value: Any) -> None:
    with path.open('wb') as stream:
        pickle.dump(value, stream, protocol=5)


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(8*1024*1024):
            digest.update(block)
    return digest.hexdigest()


def depletion_mpo(law: Any, holes: int) -> MPO:
    grids: list[list[list[Any]]] = []
    for site in range(len(law.sites)):
        occupied = site > 0 and law.one['occupied'][site-1]
        if holes == 0:
            grid = [['N' if occupied else 'Id']]
        else:
            stay = 'N' if occupied else 'Id'
            transition = [('Id', 1.), ('N', -1.)] if occupied else None
            grid = [[stay, transition], [None, stay]]
            if site == 0:
                grid = grid[:1]
            if site == len(law.sites)-1:
                grid = [[row[1]] for row in grid]
        grids.append(grid)
    dimensions = [1]+[holes+1]*(len(law.sites)-1)+[1]
    legs = [npc.LegCharge.from_qflat(law.charge_info, [[0, 0]]*dimension).bunch()[1] for dimension in dimensions]
    return MPO.from_grids(law.sites, grids, 'finite', IdL=[0]+[None]*len(law.sites),
        IdR=[None]*len(law.sites)+[0], legs=legs, max_range=len(law.sites), mps_unit_cell_width=law.lattice.mps_unit_cell_width)


def spin_mpo(law: Any) -> MPO:
    u = law.one['orbitals']
    spin = u.conj().T @ np.kron(np.eye(27), np.kron(np.eye(2), np.diag([.5, -.5]))) @ u
    body = []
    for block in range(9):
        sl = slice(12*block, 12*block+12)
        k = law.one['momentum'][sl]
        body.append(np.where((k[:, None]-k[None, :]) % 3 == 0, spin[sl, sl], 0.))
    return law.literal_one_body_mpo([dict(name='Id', charge=0)], np.array(body)[None], 0, None)


def stream_image(operator: Any, source: Any) -> tuple[Any, dict[str, Any]]:
    image = source.copy()
    # This is a MATHEMATICAL upper bound on exact MPO x MPS Schmidt rank,
    # not a numerical bond cap. Only the existing1e-13 roundoff SVD rule remains.
    rank_upper_bound = max(int(a*b) for a, b in zip(operator.H_MPO.chi[1:-1], source.chi))
    error = operator.H_MPO.apply(image, dict(compression_method='zip_up', m_temp=1,
        trunc_params=dict(chi_max=rank_upper_bound, svd_min=1e-13, trunc_cut=None)))
    return image, dict(exact_product_rank_upper_bound=rank_upper_bound,
        image_maximum_bond=max(image.chi), accumulated_streaming_SVD_epsilon=float(error.eps), svd_min=1e-13,
        scope='No new state/bond cap. Exact uncontracted MPO/source primitive image is separately retained; this canonical numerical materialization has recorded machine-level SVD debt, not a convergence theorem.')


def image_receivers(law: Any, psi: Any, total_charge: int, spin: MPO, p0: MPO, p1: MPO) -> dict[str, Any]:
    tensor = psi.get_B(0, form='B').to_ndarray()[0]
    rho = tensor @ tensor.conj().T
    field = np.array([np.trace(rho[np.ix_(law.field['momentum'] == q, law.field['momentum'] == q)]).real for q in range(3)])
    # Each image has one exact TOTAL-C3 grade. This is the actual joint PVM,
    # not a fixed matter-q assumption for the full field-dependent current.
    joint = np.zeros((3, 3))
    for f in range(3):
        joint[(total_charge-f) % 3, f] = field[f]
    a = float(np.real(p0.expectation_value(psi)))
    b = float(np.real(p1.expectation_value(psi)))
    total = np.zeros(3); total[total_charge] = float(field.sum())
    return dict(momentum=dict(joint_matter_field=joint.tolist(), matter=joint.sum(axis=1).tolist(),
        field=field.tolist(), total=total.tolist()), primitive_spin_z=float(np.real(spin.expectation_value(psi))),
        reference_depletion=[a, b, 1-a-b])


def main() -> None:
    physical_stamp, output_stamp = sys.argv[1:3]
    source_stem = ROOT/(PREFIX+physical_stamp+'_')
    output = ROOT/(PREFIX+output_stamp+'_')
    inputs = json.loads(Path(str(source_stem)+'input.json').read_text())
    completed = json.loads(Path(str(source_stem)+'result.json').read_text())
    if len(completed['cases']) != 9:
        raise ValueError('The coupled physical source is incomplete')
    model_path = Path(str(source_stem)+'constructed_model.pkl')
    law = load(model_path)
    model_hash = sha(model_path)
    spin, p0, p1 = spin_mpo(law), depletion_mpo(law, 0), depletion_mpo(law, 1)
    steps = int(round((inputs['duration']-inputs['short_start'])/inputs['dt']))
    results = {}
    for number in [55, 53]:
        for endpoint in ['initial', f't{steps}']:
            state_path = Path(str(source_stem)+f'N{number}_baseline_{endpoint}.pkl')
            wave = load(state_path)
            state_hash = sha(state_path)
            records = []
            image_paths: dict[str, list[dict[int, Path]]] = dict(J=[], QJ=[])
            for index, operator in enumerate(law.emission):
                vertex = dict(polarization=operator['polarization'], profile_sign=operator['profile_sign'],
                    actual_current_C3_charge=operator['current_C3_charge'])
                for family, field_name in [('J', 'current'), ('QJ', 'QJ')]:
                    paths = {}
                    raw_norms = {}
                    sector_receivers = {}
                    compression = {}
                    for source_charge, source in wave.items():
                        charge = (source_charge+operator['current_C3_charge']) % 3 if family == 'J' else source_charge
                        image, compression[charge] = stream_image(operator[field_name], source)
                        raw_norms[charge] = float(abs(image.norm)**2)
                        sector_receivers[charge] = image_receivers(law, image, charge, spin, p0, p1)
                        path = Path(str(output)+f'N{number}_{endpoint}_{family}{index}_r{charge}.pkl')
                        dump(path, image)
                        paths[charge] = path
                        Path(str(path)+'.primitive.json').write_text(json.dumps(dict(
                            representation='EXACT uncontracted two-layer MPO x MPS image; all finite-law CAR/field channels retained.',
                            source_model=model_path.name, source_model_sha256=model_hash,
                            source_state=state_path.name, source_state_sha256=state_hash,
                            source_total_C3=source_charge, output_total_C3=charge,
                            operator_index=index, operator_family=field_name,
                            canonical_image=path.name, numerical_materialization=compression[charge]), indent=2)+'\n')
                        del image
                        gc.collect()
                    norm2 = sum(raw_norms.values())
                    joint: Any = sum(raw_norms[r]*np.array(sector_receivers[r]['momentum']['joint_matter_field']) for r in paths)/norm2
                    total = np.array([sum(joint[m, f] for m in range(3) for f in range(3) if (m+f) % 3 == r) for r in range(3)])
                    depletion: Any = sum(raw_norms[r]*np.array(sector_receivers[r]['reference_depletion']) for r in paths)/norm2
                    receiver = dict(raw_norm2=norm2, raw_total_C3_sector_norms=raw_norms,
                        conditional_momentum=dict(joint_matter_field=joint.tolist(), matter=joint.sum(axis=1).tolist(), field=joint.sum(axis=0).tolist(), total=total.tolist()),
                        conditional_primitive_spin_z=sum(raw_norms[r]*sector_receivers[r]['primitive_spin_z'] for r in paths)/norm2,
                        conditional_reference_depletion=depletion.tolist(),
                        streaming_compression=compression,
                        conditioning='Normalized finite vertex image, NOT a probability or unitary shift. Grade0 receivers have no cross-total-C3 terms; all same-grade cross-vertex complex coherences remain in the raw Gram.')
                    vertex['current' if family == 'J' else 'counterfield_current_emission'] = receiver
                    image_paths[family].append(paths)
                records.append(vertex)
            grams = {}
            for family, arrays in image_paths.items():
                gram = np.zeros((4, 4), complex)
                for a in range(4):
                    for b in range(a, 4):
                        value = 0j
                        for r in arrays[a].keys() & arrays[b].keys():
                            first = load(arrays[a][r]); second = load(arrays[b][r])
                            value += first.overlap(second)
                            del first, second
                            gc.collect()
                        gram[a, b] = value
                        gram[b, a] = value.conjugate()
                grams[family] = np.stack([np.real(gram), np.imag(gram)], axis=-1).tolist()
            key = f'N{number}_{endpoint}'
            results[key] = dict(vertices=records, coherent_cross_vertex_Gram=grams)
            Path(str(output)+'emission_result.json').write_text(json.dumps(dict(physical_source=physical_stamp, results=results,
                meaning='Saved-state full Peierls J and before-cut QJ images; exact primitive networks plus streamed canonical arrays. Joint grade, not fixed matter recoil; raw model-unit weights are not emission probabilities.'), indent=2)+'\n')
            print(json.dumps(dict(case=key, vertices=records)), flush=True)


if __name__ == '__main__':
    main()
