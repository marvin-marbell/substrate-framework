"""Actual full-CAR current images on fresh coupled states, not momentum shifts."""
from __future__ import annotations
import json
from pathlib import Path
import pickle
import sys
from typing import Any
import numpy as np
from rich_recoil_current_wave_20261016_model import exact_image
from rich_recoil_current_wave_20261016_observe import CoherentWave

ROOT = Path(__file__).resolve().parent
PREFIX = 'rich_recoil_current_wave_20261016_'


def load(path: Path) -> Any:
    with path.open('rb') as stream:
        return pickle.load(stream)


def complex_data(array: np.ndarray) -> list[Any]:
    return np.stack([array.real, array.imag], axis=-1).tolist()


def characterize(law: Any, images: dict[int, Any]) -> tuple[dict[str, Any], dict[int, Any]]:
    raw_norms = {r: float(abs(psi.norm)**2) for r, psi in images.items()}
    total = sum(raw_norms.values())
    normalized = {r: psi.copy() for r, psi in images.items()}
    for psi in normalized.values():
        psi.norm /= np.sqrt(total)
    frame = CoherentWave(normalized)
    one = frame.conditional_one_body(np.eye(len(law.field['momentum'])), intrablock=True)
    u = law.one['orbitals']
    sz = u.conj().T @ np.kron(np.eye(27), np.kron(np.eye(2), np.diag([.5, -.5]))) @ u
    record = dict(raw_norm2=total, raw_total_C3_sector_norms=raw_norms,
        conditional_momentum=frame.momentum(law), conditional_primitive_spin_z=float(np.sum(sz*one).real),
        conditional_reference_depletion=frame.sea_depletion(law), maximum_image_bond=max(max(psi.chi) for psi in images.values()),
        conditioning='Normalized operator image for analyzing a finite vertex, NOT an emission probability, a unitary shift, or a statement that conditioning preserves sector weights.')
    return record, normalized


def main() -> None:
    stamp = sys.argv[1]
    stem = ROOT/(PREFIX+stamp+'_')
    inputs = json.loads(Path(str(stem)+'input.json').read_text())
    completed = json.loads(Path(str(stem)+'result.json').read_text())
    if len(completed['cases']) != len(inputs['numbers'])*len(inputs['protocols']):
        raise ValueError('Physical producer is not complete')
    law = load(Path(str(stem)+'constructed_model.pkl'))
    steps = int(round(inputs['duration']/inputs['dt']))
    results = {}
    for number in [55, 53]:
        for endpoint in ['initial', f't{steps}']:
            wave = load(Path(str(stem)+f'N{number}_baseline_{endpoint}.pkl'))
            records = []
            current_images = []
            emission_images = []
            for operator in law.emission:
                charge = operator['current_C3_charge']
                current = {(r+charge) % 3: exact_image(operator['current'], psi) for r, psi in wave.items()}
                emission = {r: exact_image(operator['QJ'], psi) for r, psi in wave.items()}
                jc, _ = characterize(law, current)
                ec, _ = characterize(law, emission)
                records.append(dict(polarization=operator['polarization'], profile_sign=operator['profile_sign'],
                    actual_current_C3_charge=charge, current=jc, counterfield_current_emission=ec))
                current_images.append(current)
                emission_images.append(emission)
            grams = {}
            for name, arrays in [('J', current_images), ('QJ', emission_images)]:
                gram = np.zeros((4, 4), complex)
                for a in range(4):
                    for b in range(4):
                        gram[a, b] = sum(arrays[a][r].overlap(arrays[b][r]) for r in arrays[a].keys() & arrays[b].keys())
                grams[name] = complex_data(gram)
            key = f'N{number}_{endpoint}'
            results[key] = dict(vertices=records, coherent_cross_vertex_Gram=grams)
            with Path(str(stem)+key+'_emission_images.pkl').open('wb') as stream:
                pickle.dump(dict(J=current_images, QJ=emission_images), stream, protocol=5)
            Path(str(stem)+'emission_result.json').write_text(json.dumps(dict(results=results,
                meaning='Actual same-law full-CAR J_delta and before-cut Q_counter J_delta images, with retained sea/internal/field channels. J changes total C3 by its measured character; QJ does not mix total-C3 sectors, but nonunitary conditioning can reweight them. Neither current nor its normalized image is identified with a unitary recoil shift.'), indent=2)+'\n')
            print(json.dumps(dict(case=key, vertices=records)), flush=True)


if __name__ == '__main__':
    main()
