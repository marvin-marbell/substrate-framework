"""Exact retained total-J fibres and sparse factor snapshots, no j penalty."""
import numpy as np
from scipy import sparse
from rich_rotcov_gauge_20261015_sparse import SparseRoundoff


def body_isometry(full,radial_count):
    # The supplied full isometry is V_body tensor I_radial.
    return full[::radial_count,::radial_count].tocsr()


def explicit(operator,target_isometry,source_isometry=None):
    source_isometry=target_isometry if source_isometry is None else source_isometry
    vt=body_isometry(target_isometry,operator.nr);vs=body_isometry(source_isometry,operator.nr);factory=SparseRoundoff()
    result=sparse.csr_matrix((target_isometry.shape[1],source_isometry.shape[1]),dtype=complex);cache_t={};cache_s={}
    def restrict(v,rows,cache):
        key=tuple(rows)
        if key not in cache:
            indices=(rows[:,None]*operator.ng+np.arange(operator.ng)[None,:]).ravel();cache[key]=v[indices]
        return cache[key]
    for rows,cols,matter,angle,radius in operator.blocks:
        left=restrict(vt,rows,cache_t);right=restrict(vs,cols,cache_s)
        angular=factory.kron(matter,factory.csr(angle));reduced=left.conj().T@angular@right
        result+=factory.kron(reduced,factory.csr(radius))
    if operator.field is not None:
        for j,matrix in operator.field.items():
            rows=np.flatnonzero(operator.source['spin']['j']==j)
            left=restrict(vt,rows,cache_t);right=restrict(vs,rows,cache_s)
            result+=factory.kron(left.conj().T@right,factory.csr(matrix))
    return result.tocsr(),factory.snapshot()


def csr_snapshot(output,key,matrix):
    matrix=matrix.tocsr();output[key+'_data']=matrix.data;output[key+'_indices']=matrix.indices;output[key+'_indptr']=matrix.indptr;output[key+'_shape']=np.array(matrix.shape)


def snapshot_operator(operator,output,prefix):
    for i,(rows,cols,mat,angle,radius) in enumerate(operator.blocks):
        key=f'{prefix}_term{i}';output[key+'_rows']=rows;output[key+'_cols']=cols;csr_snapshot(output,key+'_matter',mat);output[key+'_orientation']=angle;output[key+'_radial']=radius
    if operator.field is not None:
        for j,matrix in operator.field.items():output[prefix+f'_field_j{int(2*j)}']=matrix
    output[prefix+'_dimension']=np.array(operator.shape)
