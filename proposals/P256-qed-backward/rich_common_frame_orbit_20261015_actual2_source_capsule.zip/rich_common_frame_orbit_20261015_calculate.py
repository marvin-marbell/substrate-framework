"""Actual NEW radial/frame/Gauss/colour/source spectrum and physical response."""
import json,resource,sys
from pathlib import Path
import numpy as np
from scipy import sparse
from scipy.linalg import eigh,expm
from scipy.sparse.linalg import eigsh,expm_multiply,spsolve
from rich_common_frame_orbit_20261015_model import build,law,observable,coupled,source,FormOperator,full_raw_source_gram
from rich_common_frame_orbit_20261015_frame import coordinate_noether,radial_form_readout
from rich_common_frame_orbit_20261015_reduce import explicit,csr_snapshot,snapshot_operator


def mean(v,op):return float(np.vdot(v,op@v).real)
def length(v):return float(np.linalg.norm(v))
def norm(op):return float(sparse.linalg.norm(op))


def lowest(matrix,p):
    dimension=matrix.shape[0]
    if dimension<=p['dense_threshold']:
        values,vectors=eigh(matrix.toarray(),check_finite=False);complete=True
    else:
        values,vectors=eigsh(matrix,k=min(p['low_eigenstates'],dimension-2),which='SA',tol=p['eigen_tolerance'],v0=np.linspace(.2,1.,dimension));order=np.argsort(values);values=values[order];vectors=vectors[:,order];complete=False
    residual=max(length(matrix@vectors[:,i]-values[i]*vectors[:,i]) for i in range(len(values)))
    return values,vectors,dict(dimension=dimension,nonzeros=matrix.nnz,complete_spectrum=complete,eigenstates=len(values),eigen_residual=residual,Hermiticity=norm(matrix-matrix.conj().T))


def j_operators(model,name):
    s=model['sectors'][name];field=[observable(model,name,matter=a) for a in s['frame']['left']];material=[observable(model,name,orientation=a) for a in model['rotor']['L']]
    return field,material


def j2_apply(v,field,material):
    result=np.zeros_like(v)
    for a,b in zip(field,material):
        moved=a@v+b@v;result+=a@moved+b@moved
    return result


def snapshot(model,path):
    arrays={};meta={}
    for name,s in model['sectors'].items():
        arrays[name+'_masks']=np.array(s['native']['masks'],dtype=np.uint64);arrays[name+'_spinU']=s['spin']['U'];arrays[name+'_spin_labels']=np.array(s['spin']['labels']);csr_snapshot(arrays,name+'_colour_P',s['native']['P']);csr_snapshot(arrays,name+'_frame_P',s['frame']['P']);snapshot_operator(law(model,name),arrays,name+'_H')
        meta[name]=dict(matter_dimension=len(s['spin']['j']),full_dimension=len(s['spin']['j'])*10*model['radial'].count,raw_colour_dimension=s['native']['raw_dimension'],raw_frame_dimension=s['frame']['P'].shape[0],right_spin_multiplets=s['spin']['multiplets'],right_Spin_Gauss=s['frame']['Gauss'],colour_Gauss=s['colour_Gauss'],frame_isometry=s['frame']['isometry'],frame_left_equals_reduced=s['frame']['left_equals_reduced'],spin_basis_unitarity=s['spin']['unitarity'],complete_spin_basis=s['spin']['completion'])
    arrays['material_U']=model['material']['U'];arrays['material_labels']=np.array(model['material']['labels']);arrays['material_quadrature_R']=model['rotor']['R'];arrays['material_quadrature_weights']=model['rotor']['weights']
    np.savez_compressed(path.with_suffix('.npz'),**arrays)
    result=dict(kind='NEW_EXACT_FACTOR_H_SNAPSHOT_BEFORE_EXPENSIVE_SPECTRA',parameters=model['parameters'],sectors=meta,radial=[radial_form_readout(model['radial'],j) for j in model['frame_js']],M_rad=model['radial'].mass,I='M_rad*r^2/2',matrix_metric=model['parameters']['matrix_metric'],frame_js=model['frame_js'],peak_rss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,sparse_roundoff=model['sparse'].snapshot(),scope='Actual new factors/isometries are saved, not old H/state/cost replay. This selected band-pair/PW19/material/radial Galerkin control is NOT primary charge-orbit/EM integration.')
    path.write_text(json.dumps(result,indent=2)+'\n');return result


def main():
    inp=Path(sys.argv[1]);out=Path(sys.argv[2]);p=json.loads(inp.read_text());model=build(p);base=out.with_name(out.stem.replace('_result',''))
    construction=snapshot(model,base.with_name(base.name+'_construction.json'));print(json.dumps(dict(stage='new_factor_snapshot',dimensions={k:v['full_dimension'] for k,v in construction['sectors'].items()},peak_rss_KiB=construction['peak_rss_KiB'])),flush=True)
    neutral=model['sectors']['neutral'];h0=law(model,'neutral');maxj=int(round(max(neutral['spin']['j'])+1));reference_candidates=[];neutral_spectra={}
    for J in range(maxj+1):
        v=coupled(model,'neutral',float(J),0.)
        if not v.shape[1]:continue
        matrix,ledger=explicit(h0,v);energies,vectors,meta=lowest(matrix,p);neutral_spectra[J]=(matrix,energies,vectors,v)
        reference_candidates.append(dict(J=J,energy=float(energies[0]),numerics=meta))
    ref=min(reference_candidates,key=lambda x:x['energy']);J0=ref['J'];matrix,e0,vec0,v0=neutral_spectra[J0];ground=v0@vec0[:,0];energy=float(e0[0]);field0,material0=j_operators(model,'neutral')
    np.savez_compressed(base.with_name(base.name+'_reference.npz'),neutral_ground=ground,reference_energy=energy,reference_J=J0)
    field_side={name:coordinate_noether(s,int(round(s['op']['N'].diagonal().real.mean()))) for name,s in model['sectors'].items()}
    sources={};source_states={};spectra={};frame_controls={};source_checks={}
    for name,kind,spins in [('lepton','lepton',[.5]),('antilepton','lepton',[.5]),('baryon','baryon',[.5,1.5]),('antibaryon','baryon',[.5,1.5])]:
        s=model['sectors'][name];h=law(model,name);field,material=j_operators(model,name);spectra[name]={};frame_controls[name]={}
        for J in spins:
            family={};selected=None
            for M in np.arange(-J,J+1):
                operator=source(model,name,kind,J,float(M));family[str(float(M))]=operator.readout
                if M==J:selected=operator
            key=f'{name}:{J}';source_checks[key]=family
            raw=selected@ground;strength=float(np.vdot(raw,raw).real);created=raw/np.sqrt(strength);source_states[key]=created
            np.savez_compressed(base.with_name(base.name+'_source_checkpoint.npz'),neutral_ground=ground,reference_energy=energy,**{k.replace(':','_'):v for k,v in source_states.items()})
            gram=selected.matrix.conj().T@selected.matrix
            middle=FormOperator(neutral,neutral,model['rotor'],model['radial'],[(gram,np.eye(10),0)])
            full_gram,count=full_raw_source_gram(model,name,kind,J)
            physical_strength=mean(ground,full_gram);matter_strength=mean(ground,middle)
            joint=j2_apply(created,field,material);source_j2=float(np.vdot(created,joint).real)
            sources[key]=dict(raw_retained_strength=strength,full_unprojected_polynomial_strength=physical_strength,retained_matter_unprojected_radial_strength=matter_strength,omitted_matter_source_strength=physical_strength-matter_strength,omitted_radial_source_strength=matter_strength-strength,raw_image_masks=count,unfiltered_total_J2=source_j2,J2_variance=length(joint-source_j2*created),conditional_insertion_cost=mean(created,h)-energy,frame_kinetic=mean(created,observable(model,name,field_kind='frame')),radial_kinetic=mean(created,observable(model,name,field_kind='radial')),mean_r2=mean(created,observable(model,name,field_kind='r2')),charge=float(s['op']['Q'].diagonal().real.mean()),fermion_number=float(s['op']['N'].diagonal().real.mean()))
            v=coupled(model,name,J,J);hm,ledger=explicit(h,v);energies,vectors,meta=lowest(hm,p);component=v.conj().T@raw;amplitudes=vectors.conj().T@component;weights=abs(amplitudes)**2
            bright=next((i for i,w in enumerate(weights) if w>p['bright_tolerance']),None)
            spectra[name][str(J)]=dict(lowest_energy=float(energies[0]),lowest_sector_gap=float(energies[0]-energy),lowest_computed_bright_gap=None if bright is None else float(energies[bright]-energy),low_poles=[dict(gap=float(x-energy),strength=float(w)) for x,w in zip(energies,weights)],source_projection_to_J_strength=float(np.vdot(component,component).real),unresolved_source_strength=strength-float(np.sum(weights)),numerics=meta)
            frame=observable(model,name,field_kind='frame');fm,_=explicit(frame,v);off=hm-fm;off_e,off_v,off_meta=lowest(off,p)
            frame_controls[name][str(J)]=dict(frame_off_lowest_energy=float(off_e[0]),full_lowest_frame_energy=mean(vectors[:,0],fm),full_lowest_r2=mean(v@vectors[:,0],observable(model,name,field_kind='r2')),control_numerics=off_meta,meaning='Different-law control removes ONLY the derived field-orbit kinetic, not a fitted subtraction. All couplings/radial measure/trial subspaces unchanged; source/reference/costs are not borrowed from old scalar H.')
            print(json.dumps(dict(stage='new_source_sector',source=key,strength=strength,gap=float(energies[0]-energy),source_J2=source_j2,Gauss=max(x['raw_source_Gauss'] for x in family.values()),peak_rss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)),flush=True)
            del hm,fm,off,off_v,vectors
        del h
    np.savez_compressed(base.with_name(base.name+'_source_checkpoint.npz'),neutral_ground=ground,**{k.replace(':','_'):v for k,v in source_states.items()})
    ordering={}
    for name in ['baryon','antibaryon']:
        ordering[name]=dict(full_E_threehalf_minus_half=spectra[name]['1.5']['lowest_energy']-spectra[name]['0.5']['lowest_energy'],frame_off_E_threehalf_minus_half=frame_controls[name]['1.5']['frame_off_lowest_energy']-frame_controls[name]['0.5']['frame_off_lowest_energy'])
    # Full retained neutral current response in the exact J=1 symmetry fibre
    # when the actual neutral reference is invariant. No low-pole truncation.
    currents=[law(model,'neutral',derivative=(a,)) for a in range(6)];derivative=[];contact=[];response=[];step=1e-3
    for a in range(6):
        ext=np.zeros(6);ext[a]=step;hp=law(model,'neutral',ext);hm=law(model,'neutral',-ext);numerical=(hp@ground-hm@ground)/(2*step)
        derivative.append(length(numerical+currents[a]@ground)/max(1.,length(currents[a]@ground)))
        second=law(model,'neutral',derivative=(a,a));contact.append(length((hp@ground+hm@ground-2*(h0@ground))/step**2-second@ground)/max(1.,length(second@ground)))
        if J0==0:
            v=coupled(model,'neutral',1.,0.);hc,_=explicit(h0,v);probe=v.conj().T@(currents[a]@ground)
            # z Cartesian channels carry M0; x/y have M±1 and are separately
            # retained in derivative/source norms, not falsely projected as z.
            if a%3==2:
                rows=[]
                for omega in p['frequencies']:
                    z=energy+omega+1j*p['eta'];solution=spsolve(z*sparse.eye(hc.shape[0])-hc,probe)
                    rows.append(dict(omega=omega,retarded_value_real=float(np.vdot(probe,solution).real),retarded_value_imag=float(np.vdot(probe,solution).imag),full_linear_solve_residual=length((z*solution-hc@solution)-probe)/max(1.,length(probe))))
                response.append(dict(channel=a,full_retained_virtual_dimension=hc.shape[0],current_strength=float(np.vdot(probe,probe).real),signed_retarded_resolvent=rows))
    # Current/dipole compression defect remains a declared band-pair and
    # material Galerkin issue, not repaired by changing the spin supplier.
    dipole=observable(model,'neutral',matter=model['sectors']['neutral']['op']['density_delta'],orientation=model['rotor']['integrate'](model['rotor']['R'][:,2,0]),power=0)
    dipole_scale=p['vertex_separation']/2
    ward=1j*dipole_scale*(h0@(dipole@ground)-dipole@(h0@ground))-currents[2]@ground
    # Independent physical MATRIX-FIELD orientation/radial pulse; NOT an EM
    # photon kick and not primitive-CAR physical-spin rotation.
    name='baryon';s=model['sectors'][name];state0=source_states['baryon:0.5'];shape=(len(s['spin']['j']),10,model['radial'].count)
    rotated=state0.reshape(shape)*np.exp(-1j*p['frame_rotation_kick']*s['spin']['m'])[:,None,None]
    kicked=np.zeros_like(rotated)
    for j in set(s['spin']['j']):
        rows=s['spin']['j']==j;kicked[rows]=np.einsum('ian,mn->iam',rotated[rows],expm(-1j*p['radial_kick']*model['radial'].moment(float(j),float(j),1)),optimize=True)
    kicked=kicked.ravel();states=[np.zeros_like(kicked) for _ in p['times']];baselines=[np.zeros_like(kicked) for _ in p['times']];event_components=[]
    for twice in range(1,int(round(2*(max(s['spin']['j'])+1)))+1,2):
        J=twice/2;v=coupled(model,name,J,.5)
        if not v.shape[1]:continue
        hm,_=explicit(law(model,name),v);x=v.conj().T@kicked;b=v.conj().T@state0;event_components.append(dict(J=J,prepared_weight=float(np.vdot(x,x).real),dimension=hm.shape[0]))
        for i,t in enumerate(p['times']):
            pair=expm_multiply(-1j*t*hm,np.column_stack([x,b]),traceA=-1j*t*hm.diagonal().sum());states[i]+=v@pair[:,0];baselines[i]+=v@pair[:,1]
        del hm
    hb=law(model,name);fb,lb=j_operators(model,name);event=[]
    frame_energy=observable(model,name,field_kind='frame');radial_r2=observable(model,name,field_kind='r2');loop_B=observable(model,name,matter=s['op']['B']);colour_energy=observable(model,name,matter=s['op']['electric']);density=observable(model,name,matter=s['op']['density_delta'])
    for t,state,baseline in zip(p['times'],states,baselines):
        record=dict(time=t,norm=float(np.vdot(state,state).real),energy=mean(state,hb),energy_drift=mean(state,hb)-mean(kicked,hb),field_left_Noether=[mean(state,a) for a in fb],material_orbital=[mean(state,a) for a in lb],total_J=[mean(state,a)+mean(state,b) for a,b in zip(fb,lb)],field_left_J2=float(np.sum([np.vdot(a@state,a@state).real for a in fb])),frame_kinetic=mean(state,frame_energy),frame_kinetic_excess=mean(state,frame_energy)-mean(baseline,frame_energy),radial_r2=mean(state,radial_r2),radial_r2_excess=mean(state,radial_r2)-mean(baseline,radial_r2),colour_electric_excess=mean(state,colour_energy)-mean(baseline,colour_energy),loop_plaquette_excess=mean(state,loop_B)-mean(baseline,loop_B),site_charge_delta_excess=mean(state,density)-mean(baseline,density))
        event.append(record)
    # Field/source Noether is distinct from physical electromagnetic current.
    rng=np.random.default_rng(221015);probe=rng.normal(size=h0.shape[0])+1j*rng.normal(size=h0.shape[0]);probe/=length(probe)
    noether=[length(h0@(a@probe+b@probe)-a@(h0@probe)-b@(h0@probe))/max(1.,length(h0@probe)) for a,b in zip(field0,material0)]
    result=dict(kind='NEW_ORDERED_MATRIX_FRAME_ORBIT_QUANTUM_CONSUMER_CONDITIONAL_CONTROL',parameters=p,construction=construction,chosen_gauging='Time-local a0, L=Mr rdot²/2+I(r)(omega-a0)²/2+i cdag cdot-a0·S_CAR-H; variation gives R_frame+S_CAR=0. Gauging/CAR/topology are inputs, not derived from trace metric.',reference=dict(energy=energy,total_J=J0,all_retained_neutral_J_candidates=reference_candidates,field_kinetic=mean(ground,observable(model,'neutral',field_kind='frame')),r2=mean(ground,observable(model,'neutral',field_kind='r2'))),field_side_Noether=field_side,source_Wigner_Gauss=source_checks,sources=sources,spectra=spectra,derived_frame_kinetic_controls=frame_controls,ordering=ordering,current=dict(physical_definition='-dH/dexternal A/B, positive contact+d²H, full route products and mechanical material rotation. No identification of field Noether spin with EM current.',same_state_first_derivative=derivative,positive_contact_second_derivative=contact,neutral_full_virtual_response=response,actual_new_dipole_compression_defect=length(ward),scope='Selected band-pair control still need not commute local EM density; no charge-continuity repair is claimed.'),physical_rotation=dict(full_tensor_HJ_random_probe_relative=noether,primitive_CAR_physical_spin_is_zero=True),event=dict(preparation='Unfiltered actual Bhalf source; LEFT matrix-field g rotation about z and actual radial-field unitary; NOT an EM photon preparation, no source/species/J filter. Same-state untouched baseline.',components=event_components,samples=event),runtime=dict(peak_rss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,sparse_roundoff=model['sparse'].snapshot()),limits=['Restricted positive-amplitude ordered Clifford orbit, not full Phi/Z quantum phase or derived ordering','Primitive CAR32, gauged right Spin/time connection, colour SU3/PW19, flavour/Q, skin/core/binding parameters remain inputs','Derived r-dependent field kinetic via actual Noether/Gauss embedding is not fitted S² exchange or elementary proton','Band-pair/PW/material/radial Galerkin control; source leakage/cost/pole strength distinct, no global all-N ground theorem','No freeCOM, integrated quantum EM photons, Lorentz/Dirac or Nature claim; independent of primary charge-orbit/EM law'])
    out.write_text(json.dumps(result,indent=2)+'\n');np.savez_compressed(out.with_suffix('.npz'),neutral_ground=ground,reference_energy=energy,event_times=p['times'],event_states=np.array(states),baseline_states=np.array(baselines),field_prepared=kicked,**{k.replace(':','_'):v for k,v in source_states.items()})
    print(json.dumps(dict(reference_J=J0,source_gaps={name:{j:data['lowest_sector_gap'] for j,data in entries.items()} for name,entries in spectra.items()},ordering=ordering,field_Noether_max=max(x['actual_left_g_derivative'] for x in field_side.values()),raw_Spin_Gauss=max(x['right_Spin_Gauss'] for x in construction['sectors'].values()),HJ=noether,final_r2_excess=event[-1]['radial_r2_excess'],final_frame_energy_excess=event[-1]['frame_kinetic_excess'],peak_rss_KiB=result['runtime']['peak_rss_KiB'])))


if __name__=='__main__':main()
