"""Original ordinary-T6 photon/current contour and required OUT creator transfer.

All photon Weyl products act on the whole supplied mode space. Full light
matrices are never declared invariant SOURCE subspaces. The long Noether
rotation is a different experiment; its literal orbital current is exposed
only as a derivative/continuity control, not substituted in ordinary T6.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction
import math
from typing import Any
import numpy as np
from flint import arb,ctx
from original_total_angular_transfer import scalar_orbital
from functional_source_photon_bank import Full108ReferenceMarks


def directed_currents(law: Any,fields: np.ndarray,links: np.ndarray,A: np.ndarray,
                      velocity: np.ndarray,Omega: float=0.) -> dict[str,Any]:
    """Positive link derivative of actual H-Omega scalar orbital, before P_T.

    With D=target-source and div=-D*, i[H,n_x]=-div(partial_A H).
    Every range-two path contributes at BOTH edges and telescopes internally.
    The body/Ref mechanical matrix has zero A derivative. EM differential
    Noether and rho.lambda_C are distinct frame terms, not erased here.
    """
    n=4*law.volume;edges=3*law.volume
    light=np.zeros((edges,n,n),complex);orbital=np.zeros_like(light)
    for x,y,block,path in law.terms(fields,links,A):
        sx,sy=slice(4*x,4*x+4),slice(4*y,4*y+4)
        for site,axis in path:
            j=3*site+axis
            light[j,sx,sy]+=1j*block;light[j,sy,sx]-=1j*block.conj().T
    for x in range(law.volume):
        for axis in range(3):
            y=int(law.target[x,axis]);sx,sy=slice(4*x,4*x+4),slice(4*y,4*y+4)
            b=(velocity[x,axis]+velocity[y,axis])*links[x,axis]*np.exp(1j*A[x,axis])/(4j*law.band.a)
            j=3*x+axis;orbital[j,sx,sy]+=1j*b;orbital[j,sy,sx]-=1j*b.conj().T
    h=law.onebody(fields,links,A);o=scalar_orbital(law,links,A,velocity)
    K=h-Omega*o;current=light-Omega*orbital
    div=np.zeros((law.volume,n,n),complex)
    for x in range(law.volume):
        for axis in range(3):
            y=int(law.target[x,axis]);div[x]+=current[3*x+axis];div[y]-=current[3*x+axis]
    errors=[]
    for x in range(law.volume):
        density=np.zeros((n,n),complex);density[4*x:4*x+4,4*x:4*x+4]=np.eye(4)
        errors.append(float(np.linalg.norm(1j*(K@density-density@K)+div[x])))
    return dict(H=h,scalar_orbital=o,J_original=light,J_orbital=orbital,
                J_pulse=current,continuity_errors=errors,
                rho='n_light-2+(Nref-4)delta_FAR; Ref occupation conserved by ordinary H',
                convention='D=target-source; div=-Dstar=outgoing-incoming; rho_dot=-div Jpositive',
                photon_J_not_replaced=True,full_EM_Noether_frame_terms_not_erased=True)


@dataclass(frozen=True)
class WeylContour:
    """Exact free-HEM contour characteristic in all represented coexact modes.

    A=legs*y, y=(a+a†)/sqrt2. A vertex phase is exp(i phase.y).
    W(z)W(w)=exp(-i Im(z†w)) W(z+w), z=phase/sqrt2.
    The external legs are literal creation/annihilation vectors, not scalars.
    """
    frequencies: np.ndarray
    incoming: np.ndarray
    outgoing: np.ndarray

    def product(self,vertices: list[tuple[np.ndarray,float]]) -> dict[str,complex|np.ndarray]:
        z=np.zeros_like(self.incoming,dtype=complex);phase=0.
        for frequency,time in vertices:
            w=np.asarray(frequency,dtype=complex)*np.exp(1j*self.frequencies*time)/math.sqrt(2)
            phase-=float(np.vdot(z,w).imag);z+=w
        vacuum=complex(np.exp(-.5*float(np.vdot(z,z).real)+1j*phase))
        overlap=complex(np.vdot(self.outgoing,self.incoming))
        return dict(vacuum=vacuum,one_photon=vacuum*(overlap-np.vdot(self.outgoing,z)*np.vdot(z,self.incoming)),
                    net_displacement=z,external_overlap=overlap)

    def split(self,left_vertices: list[tuple[np.ndarray,float]],
              right_vertices: list[tuple[np.ndarray,float]]) -> dict[str,complex|np.ndarray]:
        """Exact <0|WL a(gout) WR a†(gin)|0>; creator is NOT transported.

        Only the right displacement contracts with the outgoing annihilator.
        The combined displacement contracts with the incoming creator.
        Thus neutral-backward/charged-forward cross terms survive even when
        incoming/outgoing modes are orthogonal.
        """
        left=self.product(left_vertices);right=self.product(right_vertices)
        zl=np.asarray(left['net_displacement']);zr=np.asarray(right['net_displacement'])
        vacuum=complex(left['vacuum'])*complex(right['vacuum'])*complex(np.exp(-complex(np.vdot(zl,zr))))
        value=vacuum*(complex(np.vdot(self.outgoing,self.incoming))-complex(np.vdot(self.outgoing,zr))*complex(np.vdot(zl+zr,self.incoming)))
        return dict(vacuum=vacuum,one_photon=complex(value),left_displacement=zl,right_displacement=zr)

    def leading_two_leg(self,vertices: list[tuple[np.ndarray,float]]) -> complex:
        z=sum((np.asarray(k,dtype=complex)*np.exp(1j*self.frequencies*t)/math.sqrt(2)
               for k,t in vertices),np.zeros_like(self.incoming,dtype=complex))
        return complex(-np.vdot(self.outgoing,z)*np.vdot(z,self.incoming))


def full_car_transition(left: np.ndarray,right: np.ndarray,
                        first: np.ndarray,second: np.ndarray|None=None) -> complex:
    """Full Slater transition of one/two bilinears, with evolving neutral bra.

    Both complete occupied frames enter the transition determinant. No
    neutral return, rank-four particle closure or frozen occupied projector.
    Invertible overlap is required by this evaluation, not an invariance claim.
    """
    M=left.conj().T@right;det=complex(np.linalg.det(M))
    R=right@np.linalg.solve(M,left.conj().T)
    a=complex(np.trace(R@first))
    if second is None:return det*a
    b=complex(np.trace(R@second))
    return det*(a*b+np.trace(R@first@second)-np.trace(R@first@R@second))


def packet_outside_action(fibre: Any,marks: Full108ReferenceMarks,
                          current: np.ndarray) -> dict[str,Any]:
    """Relative packet image plus full before-crop PH controls, not closure."""
    from functional_source_photon_bank import full_packet_mark_action
    zero=Full108ReferenceMarks(np.zeros_like(marks.plus),np.zeros_like(marks.minus))
    result=full_packet_mark_action(fibre,marks.plus,marks.minus,zero.plus,zero.minus,
                                   current,np.zeros((4,4),complex))
    return result


def fraction(value: Any) -> Fraction:
    if isinstance(value,dict):
        return Fraction(int(value['exact_numerator_hex'],16),int(value['exact_denominator_hex'],16))
    return Fraction(value)


def uniform_photon_number_bound(V: int,initial_factorials: list[Any],
                                UE: Fraction,c: Fraction,coefficient_log: int,
                                duration: int=6) -> dict[str,Any]:
    """Ordinary whole-H second moment, independent of Lambda.

    rho=||Phi||HS. Original stiffness2 gives Lambda*rho^4/(64V).
    The literal heavy+light Pauli triangle b<=2^16 and Young give the
    global quartic moment <rho^4><=2^30 V^2 at absolute energy<=16V Lambda.
    Positive alignment/kinetic/Coul/Root penalties are retained. Actual
    initial/conserved E<=8V Lambda; bounded mean-light replacement leaves
    the reference below16V Lambda at the selected hierarchy, not a new state.

    For z<=1, the displacement conjugation of M=N+1 bounds its fractional
    graph norms. Duhamel [M^2,W] has relative form order3/2 and coefficient
    <=256|z|. Thus M2'<=512 C|z| <rho M^3/2>
    <=512 C|z| <rho^4>^1/4 M2^3/4. Use H_R=Hrest+P_R Hlight P_R
    on the finite-photon/compact-Phi form core. Quartic domination is uniform
    in R; strong-form/resolvent convergence and lower semicontinuity of
    ||(N+1)Psi|| remove the proof cutoffs. Evolving cutoff states are NOT
    monotone. Only ordinary Peierls fails to commute N; no driven assertion.
    """
    if V<=0 or duration!=6:raise ValueError('Original ordinary T6 only')
    ctx.prec=192
    a=[fraction(v) for v in initial_factorials]
    initial=arb(a[0].numerator)/a[0].denominator
    initial=initial**2+3*(arb(a[1].numerator)/a[1].denominator)**2+(arb(a[2].numerator)/a[2].denominator)**2
    C=arb(2)**coefficient_log
    phi4=arb(2)**30*V**2
    displacement=(arb(16)*arb(UE.numerator)/UE.denominator/(arb(c.numerator)/c.denominator)).sqrt()
    if not displacement<1:raise ValueError('Allmode original Weyl displacement premise fails')
    quarter=initial.sqrt().sqrt()+128*C*displacement*phi4.sqrt().sqrt()*duration
    M2=quarter**4
    if not M2<16:raise ValueError('Uniform whole-H moment ceiling16 not established')
    return dict(initial_Nplus1_squared_upper=str(initial.upper()),Phi_fourth_moment_upper=str(phi4.upper()),
        allmode_path_displacement_upper=str(displacement.upper()),Nplus1_squared_upper=16,
        evaluated_Nplus1_squared_upper=str(M2.upper()),
        exact_original_quartic_coefficient='Lambda/(64V)',
        coercivity_remainder='global heavy+light b<=2^16: <||Phi||HS^4><=2^30 V^2; betaD/Lambda>=-V for Lambda>=1, positive penalties retained',
        actual_energy_premise='actual ordinary conserved E<=8V Lambda; mean-light reference <=16V Lambda',
        proof_scope='global second number MOMENT; no global fourth-moment graph or driven Noether assertion',
        no_photon_mode_truncation_in_final=True)


def physical_OUT_transfer(neutral_error_log: int,late_source_error_log: int,
                          lambda_log: int,V: int,reference_Gram_lower: Fraction=Fraction(1,2)) -> dict[str,Any]:
    """Required a†OUT comparison + ONE joint physical-Gram inverse-root.

    B commutes all coexact a and ||B||<=16sqrtV on the original SOURCE
    coefficient domain/full encoded code. The bound is not a compact jet.
    For BOTH actual/ref M2<=16, ||a† delta||²<=8||delta||.
    Late (B-B0)Psi has weighted graph<=2CB*4; use interpolation separately.
    Raw two-column norm errors pay the fixed prescribed Loewdin comparison;
    the comparison receiver is never installed in place of the actual E2.
    """
    if not 0<reference_Gram_lower<=1:raise ValueError('Positive literal reference Gram margin required')
    vceil=(V-1).bit_length();CBlog=4+(vceil+1)//2
    # both moment norms <=4, source+neutral weighted terms and TWO columns
    col_log=CBlog+4+(max(neutral_error_log,late_source_error_log)+1)//2-lambda_log//16
    yref_log=CBlog+3
    gram_log=2+yref_log+col_log
    if gram_log>=-((reference_Gram_lower.denominator-1).bit_length()+1):
        raise ValueError('Prescribed physical joint Gram comparison not positive')
    # Functional calculus on Gram>=s/2: inverse-root <=sqrt(2/s),
    # derivative <=(1/2)(2/s)^(3/2), not the old static s=1/2 constant.
    inverse_squared_log=(reference_Gram_lower.denominator-1).bit_length()+1
    inverse_log=(inverse_squared_log+1)//2
    derivative_log=(3*inverse_squared_log+1)//2
    receiver_log=3+derivative_log+2*yref_log+col_log
    return dict(global_SOURCE_CB_log2_upper=CBlog,
        raw_OUT_two_column_error_log2_upper=col_log,actual_joint_Gram_error_log2_upper=gram_log,
        actual_Gram_lower=str(reference_Gram_lower/2),reference_Gram_lower=str(reference_Gram_lower),
        physical_receiver_error_log2_upper=receiver_log,
        inverse_root_log2_upper=inverse_log,inverse_root_derivative_log2_upper=derivative_log,
        rate='Lambda^-1/16 from NEW ordinary unweighted Lambda^-1/8, not driven647/C2',
        late_B_to_B0_paid_separately=True,source_global_bound_requires_original_domain_binding=True,
        actual_OUT='a†gout (Bplus+Bminus) U_N(6) Xi; unchanged gout and SAME global physical Gram',
        no_NEW_receiver_or_state_normalization=True)


def ordinary_actual_graphs(weighted: dict[str,Any],V: int) -> dict[str,Any]:
    """NEW Omega=0 actual-side IMS, not a relabelled driven C2 estimate.

    Every strong graph below is on the ORIGINAL regular Dirichlet union D.
    No zero-extended state is asserted to lie in D(Hwhole). Whole evolution
    is compared separately by the original form/Agmon boundary and global M2.
    On D, put beta I with the potential: h0+beta=Kfast+Wtilde+positive
    commuting EM/HC/Root/harm, Wtilde>=0. Covariant integration by parts gives
      Re<Kpsi,Wtilde psi> >= -chi <covLap Wtilde>/4.
    Original quartic/colour/alignment second derivatives scale at most
    Lambda^5/4, chi=Lambda^-1/2. Thus ||Kfast psi||² is bounded by the
    conserved Dirichlet strong graph squared plus C_N Lambda^3/4.

    C_N^128 V^64 pays regular jets through order2, inverse metric products,
    encoded charge row squares and channel sums: at most16 regular jet
    factors of size C_N^8 and at most90V coordinates. Root/D field
    derivatives vanish. This scalar count alone is NOT a graph argument.

    The original cutoff neutral f(h/L) retains ||hXi||<=L. Its D-cutoff
    commutator is the original regular cutoff row, not global SOURCE jets.
    For true creator use g=x f, Cf1(g)<2^512 by original Cf2/3 and support;
    a RAWtau=0 gives ||a hXi||<=32 CL Cf1(g). CCR pays [h,a†].
    Multiplication by the ORIGINAL bounded C2 SOURCE preserves D(H_D)
    using regular jets<=2 and even heavy/Root endpoint commutation.
    beta[D,B]P costs Lambda^1/2 in the STRONG source graph; do not call
    this O(L). The separate conserved source FORM expectation is O(L):
    BP lies in P, each periodic defect edge has PZedgeP=0, and initial
    Q<=C_N Lambda^-1/8 pays beta cross terms. Compact kinetic product
    rules use E<=8V Lambda; their chi M1 Pi term is at most C_N Lambda^1/4.
    The same form bound applies to the original true-photon SOURCE via
    CCR. At later times actual Q/PDQ are separately priced, not discarded.
    """
    ledger=weighted['ledger'];common=int(ledger['actual_common_coefficient_log2_upper'])
    lam=int(ledger['selected_log2_lambda_lower']);v=(V-1).bit_length()
    window=common+2
    covariance=int(ledger['covariance_log2_upper'])
    source_first=int(ledger['global_union']['source_first_log2'])
    if common<max(source_first,covariance,1231):raise ValueError('Original universal regular coefficient not bound')
    derivative=128*common+64*v+4096
    hgraph=window+5*common+16*v+2048
    kgraph=max(hgraph,(derivative+1)//2)+4
    distance=hgraph+199+8
    mixed_squared=10+(distance+1)//2+kgraph+1
    mixed=(mixed_squared+1)//2
    cross=3+34+v+mixed
    potential=3+304+(distance+1)//2
    remainder=3+64+2*v+8*common
    coefficient=max(cross,potential,remainder)+4
    late=source_first+(distance+1)//2+4
    initial=8*common+64*v+1231+4096
    q_coefficient=(common+2)//2
    # Q norm uses original absolute8V Lambda and G>=Utrial>
    # (132/5)V Lambda^5/4. Rest >=-C_N V Lambda, so Q²<=2C_N Lambda^-1/4.
    auxiliary=q_coefficient+3+4+6+(v+1)//2
    barrier=int(ledger['global_union']['barrier_log2_coefficient_lower'])
    action=int(ledger['global_union']['action_log2_lower'])-2
    # SAME spatial D and physical f/L/Z. Ecut=onequarter original barrier
    # is only an auxiliary spectral comparison, not a new preparation.
    # Compact initial chi B a†Xi has a whole-H domain proof by regular C2
    # product rule on its interior support. The evolved Dirichlet zero
    # extension is NEVER asserted H2. PHP strong source graph is O(L):
    # at Ecut~Lambda^1/2 its high tail is O(Lambda^-1/8).
    # Low side uses the original Agmon action, weakened by TWO bits.
    # Full-H compact-source high tail at G/2 is O(Lambda^-3/4).
    # Qlow solves (QHQ-Hlow)X=-QHP: <=2 beta||D||/G. Its codeflow
    # integral <=2T beta²||D||²/G=O(Lambda^-1/4), plus initial Q.
    # Do not integrate beta times the crude Q norm.
    if lam//4+action < lam.bit_length()+8:
        raise ValueError('Whole Agmon action does not dominate comparison powers')
    boundary=hgraph-barrier+8+source_first
    auxiliary=max(auxiliary,derivative+16*v+common+64)
    coefficient=max(coefficient,auxiliary,boundary)+2
    return dict(protocol='ORIGINAL ordinary Omega=0/T6',window_coefficient_log2=window,
        original_regular_C_N_log2=common,covariant_potential_second_jet_coefficient_log2_upper=derivative,
        conserved_Dirichlet_neutral_h_graph_coefficient_log2_upper=hgraph,
        conserved_Dirichlet_neutral_h_graph_Lambda_power='3/8',
        conserved_Dirichlet_SOURCE_h_graph_coefficient_log2_upper=hgraph,
        conserved_Dirichlet_SOURCE_h_graph_Lambda_power='1/2',
        conserved_Dirichlet_SOURCE_form_coefficient_log2_upper=hgraph,
        conserved_Dirichlet_SOURCE_form_Lambda_power='3/8',
        conserved_PHP_SOURCE_h_graph_Lambda_power='3/8',
        PHP_graph_does_NOT_discard_actual_beta_PD_Q=True,
        original_spatial_barrier_coefficient_log2=barrier,
        auxiliary_spectral_comparison_threshold_Lambda_power='1/2',
        auxiliary_spectral_comparison_threshold_coefficient_log2=barrier-2,
        ordinary_whole_to_D_error_coefficient_log2_upper=boundary,
        ordinary_whole_to_D_error_log2_upper=boundary-lam//8,
        compact_initial_comparison_domain_proved=True,
        whole_actual_SOURCE_strong_H_domain_asserted=False,
        strong_Kfast_coefficient_log2_upper=kgraph,strong_Kfast_Lambda_power_upper='1/2',
        actual_distance_squared_coefficient_log2_upper=distance,actual_distance_squared_Lambda_power='-5/8',
        NEW_ordinary_full_D_IMS_squared_coefficient_log2_upper=mixed_squared,
        NEW_ordinary_full_D_IMS_squared_Lambda_power='-1/4',
        NEW_ordinary_unweighted_reference_coefficient_log2_upper=coefficient,
        NEW_ordinary_unweighted_reference_error_log2_upper=coefficient-lam//8,
        initial_CAR_comparator_coefficient_log2_upper=initial,
        initial_CAR_comparator_norm_error_log2_upper=initial-lam//4,
        initial_CAR_scope='short SAME f/floor/Z filter-time Duhamel + original RAW full-cluster Kato; conditional non-ground Slater banks, full Theta',
        late_SOURCE_norm_coefficient_log2_upper=late,
        late_SOURCE_norm_error_log2_upper=late-5*lam//16,
        initial_true_SOURCE_CCR_norm_error_log2_upper=max(late-5*lam//16,152+512+304+32-window-3*lam//8)+4,
        mean_Gauss_norm_error_log2_upper=4+16+v-lam//2,
        Q_norm_log2_upper=q_coefficient-lam//8,
        Q_AND_beta_PD_Q_log2_upper=auxiliary-lam//8,
        no_driven_or_oldshadow_rate_retag=True,no_reference_graph_gate=True,
        mean_Gauss_is_charge_square_NOT_Gaussian=True,
        strong_graph_scope='ORIGINAL regular Dirichlet D only; never global SOURCE derivatives or zero-extension H2',
        whole_boundary_scope='original Omega=0 whole-to-D form Agmon; source bound globally, jets only on regular cutoff support',
        mean_Gauss_convention='Hfast retains heavy gGG(q); B0=chi/2[Qt gGG(0)^-1 Qt-Qh gGG(0)^-1 Qh]; full-mean supplier discrepancy separately paid',
        actual_state_not_projected_or_refiltered=True)


def initial_photon_cloud(weighted: dict[str,Any],V: int) -> dict[str,Any]:
    """Only a paid unnormalized comparator; original state/OUT stays mixed."""
    ledger=weighted['ledger'];lam=int(ledger['selected_log2_lambda_lower'])
    window=int(ledger['actual_common_coefficient_log2_upper'])+2
    cb=4+(((V-1).bit_length()+1)//2)
    v=(V-1).bit_length()
    neutral=16+v+117+304-window-3*lam//8
    # Second Fourier pullthrough has the first second-commutator plus the
    # two first-commutator Touchard term. Since displacement<=1 and L>=1,
    # Cf2*CL²*(1+Phi²)/L dominates both; original global quartic moment
    # pays <=2^16 V. This is a factorial norm, not the moment of N².
    second=32+2*v+199+2*304-window-3*lam//8
    return dict(neutral_A1_log2_upper=neutral,
        neutral_A2_log2_upper=second,
        SOURCE_true_creator_vacuum_comparator_error_log2_upper=cb+4+neutral,
        original_Cf1_log2_upper=117,original_CL_log2_upper=304,
        original_L_coefficient_log2=window,rate='Lambda^-3/8 before endpoint interpolation',
        original_initial_photon_vacuum_not_asserted=True,
        comparator_Pvac_not_installed_or_normalized=True,
        photon_CCR_not_norm_error_forwarding=True)


def reference_Gram_admission(V: int,UE: Fraction,c: Fraction,
                             initial_error_log: int,lambda_log: int) -> dict[str,Any]:
    """Literal mixed-grade reference Y, not old static/vacuum Gram default.

    The original Cbeta has duplicated singular values:
    sum sigma²=33/40, product sigma²=13481/160000.
    Hence sigma_min²>=product/sum>1/16. At each actual mean branch,
    positive/negative Bloch projectors have rank2. Ref4plus uses empty
    positive electrons; Ref0minus uses the occupied NEGATIVE sea, with
    four genuine positive Spect spectators giving a positive increment.
    No interacting neutral return is assumed. Thus SOURCE norm² is at
    least 2 sigma_min² ||eta_eff||². All actual19 source paths
    have length<D+2<2^98; tanh36>1-2^-102, so their signed screening
    product magnitude>15/16. The tiny recoil changes no eta norm.
    The unnormalized CAR comparator has norm>=1/2, so free Gram>=1/64;
    hard forward/outgoing photon IDs make its offdiagonal EXACTLY zero.

    Hmean Peierls W-I on vacuum costs <=6*2^304*d. FullHC and harmonic
    occupation/source graph cost <=2^1024 UE V^4; they are retained, not
    Gaussianized. MeanGauss costs <=6*2^16 V Lambda^-1/2.
    Number interpolation pays a† on the neutral difference. This proves
    Gref>=1/128 on the actual mixed neutral endpoint.
    """
    ctx.prec=256
    if initial_error_log>=-2:raise ValueError('CAR comparator norm margin unproved')
    v=(V-1).bit_length();cb=4+(v+1)//2
    displacement=(arb(16)*arb(UE.numerator)/UE.denominator/(arb(c.numerator)/c.denominator)).sqrt()
    ph=arb(6)*arb(2)**304*displacement
    hc_harm=arb(2)**1024*(arb(UE.numerator)/UE.denominator)*V**4
    ordinary_small=ph+hc_harm
    neutral_log=math.ceil(float((ordinary_small.log()/arb(2).log()).upper()))
    neutral_log=max(neutral_log,3+16+v-lambda_log//2,initial_error_log)+3
    column_log=cb+4+(neutral_log+1)//2
    gram_log=2+cb+3+column_log
    if gram_log>=-7:raise ValueError('Literal mixed-grade reference Gram margin not proven')
    determinant=Fraction(13481,160000);singular_sum=Fraction(33,40)
    if determinant/singular_sum<=Fraction(1,16):raise ValueError('Original complex quaternion invertibility bound failed')
    return dict(free_raw_joint_Gram_lower='1/64',reference_raw_joint_Gram_lower='1/128',
        actual_raw_joint_Gram_lower_after_transfer='1/256',
        literal_reference_neutral_difference_log2_upper=neutral_log,
        literal_reference_OUT_column_error_log2_upper=column_log,
        literal_reference_Gram_perturbation_log2_upper=gram_log,
        exact_complex_quaternion_min_singular_squared_lower=str(determinant/singular_sum),
        original_screened_path_magnitude_lower='15/16',
        BOTH_templates_and_Ref_banks_before_ONE_Gram=True,
        raw_Gram_not_native_response_metric=True,
        actual_reference_OUT_mixed_photon_grades_retained=True)


def leading_reference_factorization(descriptor: dict[str,Any],paired: dict[str,Any],
                                    screen: dict[str,Any]) -> dict[str,Any]:
    """Exact leading SOURCE factor, not a lower-Gram replacement.

    At the point Clifford reference LABELS=[I,G2G3,G3G1,G1G2]/2,
    M=sum beta LABELS. Trace(M†M)=sum|beta|², and both sea projectors
    give Tr(M†P±M)=Tr(M†M)/2. With the ORIGINAL Mc and harmonic
    birth phase, Parseval gives s=(Tr M†M/2)||Mc eta||². Ref0 adds
    the positive Spect insertion R; its separately enclosed correction
    is NOT omitted. Original fork amplitudes/fn/Z become actual wq,
    not two re-normalized state preparations.

    For prescribed forward/outgoing photon IDs G0=s I and C0_2=0.
    Write C2_q=s (UE/V)cq, G1_21,q=s (UE/V)gq, M0_1,q=s mq.
    Differentiating the ONE joint inverse root at sI yields
      Aq/(UE/V)=sqrt(wq)[cq-.5(sum_r wr gr)mq].
    s cancels against original input sqrt(s) and output sqrt(s);
    no SOURCE/column rescaling is installed. Actual Phi*_ms, theta,
    P0->Utheta P0 Utheta†, finite Spect R and GLOBAL G0-sI perturbations
    are the literal C/G/m enclosures below. The coarse1/128 only
    stabilizes later remainder/actual-OUT transfer, never this identity.
    """
    ctx.prec=256
    if int(screen['literal_LEGAL19_geometry']['N'])!=int(descriptor['N']):
        raise ValueError('Leading SOURCE screen geometry differs')
    from prepared_neutral_full_field import BETA
    beta_squared=sum((Fraction.from_float(float(z.real))**2+
                      Fraction.from_float(float(z.imag))**2 for z in BETA),Fraction(0))
    eta_screen=arb(screen['numerical_Arb_witness']['screened_eta_squared'])
    common=eta_screen*(arb(beta_squared.numerator)/beta_squared.denominator)/2
    harmonic=paired['ordinary_all512_fullGaussian_harmonic']
    spect=paired['new_R4_source_slack_enclosure']
    # Actual leading departures from scalar point G0, not a N(k) floor.
    gram_error=arb(harmonic['zeroth_GLOBAL_Gram_operator_error'])+arb(
        spect['source_and_zeroth_GLOBAL_Gram_relative_increment_upper'])
    leading_error=arb(harmonic['GLOBAL_leading_relative_error'])+arb(spect['GLOBAL_leading_relative_error'])
    if not gram_error<arb('1e-20'):raise ValueError('Actual mean leading Gram correspondence unproved')
    gcap=arb(paired['joint_raw_G_centre_cap'])
    rows={}
    for bank in ('plus','minus'):
        raw=paired['result'][bank];errors={k:arb(v) for k,v in raw['raw_component_errors'].items()}
        m=raw['frozen_raw_m'];mabs=(arb(m['real'])**2+arb(m['imag'])**2).sqrt()
        # Retain Gram-coherence cross, including its error-product term.
        disk=errors['C']+(errors['G']*mabs+gcap*errors['m']+errors['G']*errors['m'])/2
        # GLOBAL leading amplitude payment is normalized to UE/V already:
        # subtract OUTSIDE sqrt(w), separately from the raw-component disk.
        coefficient=arb('0.49').sqrt()*(arb(raw['frozen_raw_C']['real'])-gcap*mabs/2-disk)-8*leading_error
        rows[bank]=dict(reconstructed_leading_lower=str(coefficient.lower()),
            current_C_error=str(errors['C']),joint_Gram_G_error=str(errors['G']),
            forward_m_error=str(errors['m']),reconstructed_C_G_m_disk=str(disk.upper()),
            GLOBAL_leading_structured_payment=str((8*leading_error).upper()),
            actual_joint_photon_coherence_term_retained=True)
    return dict(point_common_SOURCE_norm_squared=str(common),
        beta_squared_exact=str(beta_squared),actual_screened_eta_squared=str(eta_screen),
        point_identity='s=.5 Tr(Mdag M)||Mc eta||²; G0=sI; C0_nonforward=0',
        actual_non_scalar_leading_Gram_relative_error=str(gram_error.upper()),
        actual_harmonic_Spect_finiteN_leading_error=str(leading_error.upper()),
        normalized_C_G_m_definition='C2=s(UE/V)c, G1_21=s(UE/V)g, M0_1=s m',
        one_GLOBAL_inverse_root_derivative='-.5 s^-3/2 G1, including offdiagonal photon coherence',
        fork_interval=paired['actual_bank_probability_interval'],
        branch_response='muq=sqrt(wq)[cq-.5 bar_g mq] is <F2GLOBAL|U|Psi_input_q>, not the paired-input amplitude',
        paired_actual_input='Apaired/(UE/V)=sum_q a_q muq, a_q=||Pi_Ref3or1 Psi_in||>=0, sum a_q²=1; principal a_q=sqrt(wq)',
        original_relative_phase='each normalized branch keeps its ORIGINAL fork phase; same phase in Y and input, no rephasing or state change',
        positive_paired_lower_reason='Re muq>=b>0 BOTHq; sum a_q>=1 implies Re sum a_q muq>=b, including unequal actual source norms',
        physical_input_normalization='a_q=sqrt(wq)n_q/sqrt(sum_r wr nr²); finiteR/initialcloud/norm corrections separately priced',
        fork_and_Z='original neutral fn/floor/Gamma/Z; actualw after one normalization, not reset1/2',
        harmonic_birth_phase=harmonic['common_birth_phase'],
        actual_mean_Gram_enclosure=harmonic,actual_R4_Spect_enclosure=spect,
        ordinary_all512_fullGaussian_scope=True,
        coarse_invertibility_floor_used_as_leading_Gram=False,
        reconstructed_from_raw_C_G_m_NOT_copied_mu_lower=True,banks=rows)


def joined_physical_Born(descriptor: dict[str,Any],weighted: dict[str,Any],
                         paired: dict[str,Any],ordinary: dict[str,Any],
                         gram: dict[str,Any],OUT: dict[str,Any],
                         factorization: dict[str,Any]) -> dict[str,Any]:
    """New whole actual result from explicit ordinary graph/CTC admissions.

    Only existing finite-N actual mean current/metric/harm/Coul and allmode
    remainder enclosures are read as suppliers. No old final P is copied.
    Coulomb alone has zero nonforward first e² term by exact hard-mode
    orthogonality. Its nonzero mixed correction is already retained/priced.
    The mean Gauss charge square is a bounded retained interaction and gets
    its own absolute state/OUT error, never a Gaussian determinant.
    """
    V=int(descriptor['N'])**3;UE=Fraction(descriptor['physical_family']['UE'])
    if gram['reference_raw_joint_Gram_lower']!='1/128':raise ValueError('Bind literal reference Gram')
    ctx.prec=256
    lower=min(arb(factorization['banks'][bank]['reconstructed_leading_lower']) for bank in ('plus','minus'))
    if not lower>arb('0.6'):raise ValueError('Reconstructed actual SOURCE/current/leading Gram coefficient not positive')
    relative=arb(paired['mean_allmode_Born_remainder']['leading_UE_over_V_relative_remainder'])*arb(2)**128
    # Ratio between old1/2 and literal1/128 is64. Inverse-root derivatives
    # through third order cost <=64^(7/2), input/source norms and raw columns
    # cost <2^32; 2^128 pays these without assuming the old Gram margin.
    lam=int(weighted['ledger']['selected_log2_lambda_lower'])
    cb=4+(((V-1).bit_length()+1)//2)
    initial=ordinary['initial_CAR_comparator_norm_error_log2_upper']
    initial_input=cb+5+initial
    initial_receiver=3+12+2*(cb+3)+cb+4+(initial+1)//2
    logs=[ordinary['NEW_ordinary_unweighted_reference_error_log2_upper'],
          ordinary['initial_true_SOURCE_CCR_norm_error_log2_upper'],
          ordinary['mean_Gauss_norm_error_log2_upper'],
          ordinary['Q_AND_beta_PD_Q_log2_upper'],OUT['physical_receiver_error_log2_upper'],
          initial_input,initial_receiver]
    if max(logs)+8>=-12000:raise ValueError('Whole actual state/creator/Gram errors not below absolute Born budget')
    scale=(arb(UE.numerator)/UE.denominator)/V
    amplitude=(lower-relative)*scale-arb(2)**-12000
    if not amplitude>scale/2:raise ValueError('New actual nonforward amplitude lower not positive')
    return dict(physical_probability_certified=True,clock=6,Omega=0,
        actual_normalized_true_photon_SOURCE_input=True,
        actual_unconditional_binary_effect='(I-E2,E2), E2 from SAME TWO true Y and ONE joint physical Gram',
        conservative_actual_amplitude_lower=str((scale/2).lower()),
        physical_probability_lower=str(((scale/2)**2).lower()),
        stronger_evaluated_amplitude_lower=str(amplitude.lower()),
        existing_mean_leading_coefficient_lower=str(lower.lower()),
        leading_reference_factorization=factorization,
        newly_repriced_allmode_relative_remainder_upper=str(relative.upper()),
        additional_absolute_actual_field_CODE_initialCAR_OUT_budget='2^-12000',
        actual_errors_log2_upper=logs,initial_Bq_to_B0_counted_once=True,
        fullHC_Gauss_harm_nonGaussian_interactions_retained_and_priced=True,
        Born_is_NOT_native_receiver_or_Lambda_OUT_rate=True,
        actual_phi_mean='finite-N Phi*_ms/all8 twists/all64 aliases; G_infinity NOT assigned exact',
        ordinary_E0_kappa_all64_and_harmonic_boundary_preserved=True,
        no_NEW_source_filter_receiver_Z_or_photon_transport=True)
